/////////////////////////////#4

import java.io.*;

//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) throws IOException {
//        int Number, Count=0;
//        Scanner sc = new Scanner(System.in);
//        System.out.println("\n შეიტანეთ რიცხვი: ");
//        Number = sc.nextInt();
//
//        while(Number > 0) {
//            Number = Number / 10;
//            Count = Count + 1;
//        }
//        FileOutputStream fileOutputStream=new FileOutputStream("D:\\java.txt");
//        String st=Count+" ";
//        byte[]b= st.getBytes();
//        fileOutputStream.write(b);
//        fileOutputStream.close();
//    }
//}
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.InputStreamReader;
//
///////////////////////////#5
//public class Main {
//    public static void main(String[] args) throws Exception {
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//        int negativeCount=0, zeroesCounter,positiveCounter;
//        for (int i=1; i<5; i++){
//            System.out.println("Enter a number");
//            int n=Integer.parseInt(reader.readLine());
//            if (n<0){
//                negativeCount++;
//            }
//            if (n==0){
//                zeroesCounter++;
//            }
//            if (n>0){
//                positiveCounter++;
//            }
//            System.out.println("Number of negativs "+negativeCount);
//            System.out.println("Number of zero "+zeroesCounter);
//            System.out.println("Number of positive "+positiveCounter);
//        }
//
//    }
//}
/////////////#3
//public class Main {
//    public static void main(String[] args) throws Exception {
//        FileReader fileReader = new FileReader("D:\\Java.txt");
//        BufferedReader bufferedReader = new BufferedReader(fileReader);
//        char[] arr = new char[10];
//        int i=0;
//        String s=" ";
//        while ((s=bufferedReader.readLine())!=null){
//            arr[i]=s.charAt(0);
//            i++;
//        }
//        bufferedReader.close();
//        fileReader.close();
//        FileWriter fileWriter= new FileWriter("D:\\Java.txt");
//        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//        for (int j=0;j< arr.length;i++){
//            bufferedWriter.write(arr[j]+"\n");
//        }
//        bufferedWriter.close();
//    }
//}
//








