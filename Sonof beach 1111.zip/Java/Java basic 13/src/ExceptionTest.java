import java.io.FileInputStream;

public class ExceptionTest {
    public static void main(String[] args){
//        int xNumber=0;
//        int YNumber=35;
        FileInputStream fileInputStream=new FileInputStream("input.txt");
        //System.out.println(YNumber/xNumber);
    }
    //FileInputStream fileInputStream= new FileInputStream("input.txt")
}
