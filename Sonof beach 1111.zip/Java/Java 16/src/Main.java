import java.util.ArrayList;

public class Main {
    public void main(String[] args){
        ArrayList<String> list = new ArrayList<>();
        list.add("saxeli 1");
        list.add("saxeli 2");
        list.add("saxeli 3");
        list.add("saxeli 4");
        list.add("saxeli 5");

        for (int i=0; i<list.size();i++){
            System.out.println(list.get(i));
        }
    }
}
