//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) throws IOException {
//        Scanner s= new Scanner(System.in);
//        String name;
//        String lastname;
//        name= s.next();
//        lastname= s.next();
//        FileOutputStream fileOutputStream=new FileOutputStream("D:\\java.txt");
//        String st=name+" "+lastname;
//        byte[]b= st.getBytes();
//        fileOutputStream.write(b);
//        fileOutputStream.close();
//    }
//}

