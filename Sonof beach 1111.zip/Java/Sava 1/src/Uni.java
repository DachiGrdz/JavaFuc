import javax.xml.namespace.QName;

public class Uni {
    private String univename;
    private String Status;
    private String Fakulteti;

    public class Description{
        private String saxeli;
        private String gvari;
        private String asaki;
        private String PiradiN;
        private String SashQ;

        public void printInfo(){
            System.out.println("University: "+Uni.this.univename);
            System.out.println("Status: "+Uni.this.Status);
            System.out.println("faculty: "+Uni.this.Fakulteti);
            System.out.println("Name: "+this.saxeli);
            System.out.println("Surname: "+this.gvari);
            System.out.println("Age: "+this.asaki);
            System.out.println("Personal number: "+this.PiradiN);
            System.out.println("Card Type: "+this.SashQ);
        }

        public Description(String saxeli,String gvari,String asaki,String PiradiN,String SashQ){}
        public String getSaxeli(){return saxeli;}
        public void setSaxeli(String saxeli){this.saxeli = saxeli;}
        public String getGvari(){return gvari;}
        public void setGvari(String gvari){this.gvari = gvari;}
        public String getAsaki(){return asaki;}
        public void setAsaki(String asaki){this.asaki = asaki;}
        public String getPiradiN(){return PiradiN;}
        public void setPiradiN(String PiradiN){this.PiradiN = PiradiN;}
        public String getSashQ(){return SashQ;}
        public void setSashQ(String SashQ){this.SashQ = SashQ;}

    }
}
