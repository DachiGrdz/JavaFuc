public class WesieriNA {
    int SideN;
    int lenght;

    WesieriNA(){}
    WesieriNA(int SideN, int lenght){
        this.SideN=SideN;
        this.lenght=lenght;
    }

    public int getInfo() {
        System.out.println("გვერდების რაოდენობა: "+SideN);
        System.out.println("გვერდების სიგრძე: "+lenght);
        return 0;
    }

    public void Perimetri(){
        System.out.println(lenght*SideN);
    }
}
