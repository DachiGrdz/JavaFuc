public class Triangle extends WesieriNA{
    public Triangle(int SideN, int lenght){
        super(SideN,lenght);

   }
   public Triangle(){}

    public int Checking() {
        if (SideN != 3) {
            System.out.println("ეს არ არის სამკუთხედი");
        } else {
            Perimetri();
        }
        return 0;

    }
    @Override
    public void Perimetri() {
        System.out.println("სამკუთხედი პერიმეტრი: " + super.lenght * super.SideN);
    }

}
