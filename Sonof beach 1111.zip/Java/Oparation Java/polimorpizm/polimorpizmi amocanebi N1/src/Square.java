public class Square extends WesieriNA{

    public Square(){}
    public void Perimetri() {
        System.out.println("კვადრატის პერიმეტრი: "+super.lenght*super.SideN);
    }
}
