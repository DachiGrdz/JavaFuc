import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        WesieriNA n1=new WesieriNA();
        n1.lenght=scanner.nextInt();
        n1.SideN=scanner.nextInt();
        n1.Perimetri();

        Triangle t1=new Triangle();
        t1.lenght=scanner.nextInt();
        t1.SideN=scanner.nextInt();
        t1.Checking();

        Triangle t2=new Triangle(scanner.nextInt(),scanner.nextInt());
        t2.Checking();

        Square s1=new Square();
        s1.lenght=scanner.nextInt();
        s1.SideN=scanner.nextInt();
        s1.Perimetri();


    }
}