public abstract class Shape {
    public String ShapeName;

    public void setName(String ShapeName) {
        this.ShapeName = ShapeName;
    }

    abstract double area();
}
