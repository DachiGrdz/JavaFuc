public class Sphere extends Shape{
    private int r;

    Sphere(int r, String ShapeName){
        setName(ShapeName);
        this.r=r;
    }
    private static double pi=3.14;
    @Override
    double area() {
        System.out.println("სფეროს ფართობი: "+(4*pi*r*r));
        return 0;
    }
}
