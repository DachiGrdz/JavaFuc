public class Rectangle extends Shape{
    private int x;
    private int y;

    Rectangle(int x, int y, String ShapeName){
        setName(ShapeName);
        this.x=x;
        this.y=y;
    }

    @Override
    double area() {
        System.out.println("პერიმეტრი ოთხკუთხედის: "+x*y);
        return 0;
    }
}
