public class Main {
    public static void main(String[] args) {

        Sphere s1=new Sphere(15,"Sphere");
        s1.area();

        Rectangle r1=new Rectangle(20,30,"Rectangle");
        r1.area();

        Cylinder c1= new Cylinder(50, 15,"Cylinder");
        c1.area();
    }
}