public class Cylinder extends Shape{
    private int r;
    private int h;

    private static double pi=3.14;

    Cylinder(int r, int h, String ShapeName){
        setName(ShapeName);
        this.r=r;
        this.h=h;
    }
    @Override
    double area() {
        System.out.println("ცილინდრის ფართობი: "+(pi*1*r*r+2*pi*r*h));
        return 0;
    }
}
