public class Triangle extends Shape {

    private double z;

    public Triangle(double x, double y, double z) {
        this.z = z;
        this.x = x;
        this.y = y;

        this.name = "samkutxedi";

    }

    @Override
    public double perimetri() {
        return x + y + z;
    }
}
