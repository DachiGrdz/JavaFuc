public abstract class Shape {

    protected double x;
    protected double y;
    protected String name;

    public abstract double perimetri();

    public void printShapeName() {

        System.out.println("ფიგურა " + name);
    }
}

