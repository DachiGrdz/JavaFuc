public class Rectangle extends Shape {

    public Rectangle(double x, double y) {
        this.x = x;
        this.y = y;

        this.name = "martkutxedi";
    }

    @Override
    public double perimetri() {
        return 2 * (x + y);
    }
}
