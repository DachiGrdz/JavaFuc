public class Main {

    public static void main(String[] args) {


        Rectangle rectangle=new Rectangle(20,10);
        rectangle.printShapeName();
        System.out.println(rectangle.perimetri());
        System.out.println("-----------------");

        Triangle triangle =new Triangle(3,4,5);
        triangle.printShapeName();
        System.out.println(triangle.perimetri());

    }
}
