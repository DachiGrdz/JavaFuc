public class Main {
    public static void main(String[] args) {
        FullTime f1=new FullTime(1500, "Dachi");
        f1.Pay();

        System.out.println("------------------------");

        PartTime p1= new PartTime(15,500,"Bachana");
        p1.Pay();
    }
}