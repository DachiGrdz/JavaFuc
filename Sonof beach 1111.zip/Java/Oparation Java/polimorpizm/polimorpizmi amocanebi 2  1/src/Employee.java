public abstract class Employee {
    public String name;

    public void setName(String name) {
        this.name = name;
    }

    abstract double Pay();
}
