public class PartTime extends Employee{
    private int hours;
    private int salaryH;

    PartTime(int hours, int salaryH, String name){
        setName(name);
        this.salaryH=salaryH;
        this.hours=hours;
    }
    @Override
    public double Pay() {
        System.out.println("Name: "+name);
        System.out.println("Salary: "+hours*salaryH);
        return 0;
    }
}
