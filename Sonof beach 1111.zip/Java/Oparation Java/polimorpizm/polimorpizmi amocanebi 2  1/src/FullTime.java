public class FullTime extends Employee{
    private int Salary;

    FullTime(int Salary, String name){
        setName(name);
        this.Salary=Salary;
    }

    @Override
    public double Pay() {
        System.out.println("Name: "+name);
        System.out.println("Salary: "+Salary);
        return 0;
    }
}
