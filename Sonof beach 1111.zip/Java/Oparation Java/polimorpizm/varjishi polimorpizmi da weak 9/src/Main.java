public class Main {
    public static void main(String[] args) {
        Person person=new Person();
        person.lastname="grdzelishvili";
        person.firstname="Dachi";
        person.idnum="6568516940";
        person.age=19;

        person.eat();
        person.walk();
        person.speak();

        Baby baby=new Baby();
        baby.lastname="Grdzeli";
        baby.firstname="dachovani";
        baby.speak();

        System.out.println("------------------");

        Mammal m=new Mammal();
        m.name="Jina";

        Bird b=new Bird();
        b.name="Chiko";

        m.grow();
        b.grow();
        m.sound();
        m.breath();
        b.sound();
        b.breath();
    }
}