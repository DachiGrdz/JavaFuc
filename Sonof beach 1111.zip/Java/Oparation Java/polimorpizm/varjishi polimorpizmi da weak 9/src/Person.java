public class Person {
    String firstname;
    String lastname;
    String idnum;
    int age;

    void eat(){
        System.out.println(firstname+" "+lastname+" toxlaobs magrad.... ");
    }

    void walk(){
        System.out.println(firstname+" "+lastname+" is walking... ");
    }
    void speak(){
        System.out.println(firstname+" "+lastname+" is speaking.... ");
    }
}
