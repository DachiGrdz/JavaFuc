public class Bird extends Animal implements AnimalInt{

    @Override
    public void breath() {
        System.out.println("Bird "+name+" breath....");
    }

    @Override
    public void sound() {
        System.out.println("Bird "+name+" sound miaaauuuuuuuuu");
    }

    @Override
    void grow() {
        System.out.println("Bird "+name+" has grown");
    }
}
