public class Mammal extends Animal implements AnimalInt{
    @Override
    public void sound() {
        System.out.println("Mammal "+name+" sound");
    }

    @Override
    public void breath() {
        System.out.println("Mammal "+name+" breath.....");
    }

    void grow(){
        System.out.println("Mammal "+name+" has grown......");
    }
}
