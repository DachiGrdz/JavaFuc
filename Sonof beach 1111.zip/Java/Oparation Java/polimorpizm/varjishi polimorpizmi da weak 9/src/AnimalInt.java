public interface AnimalInt {
    void sound();
    void breath();
}
