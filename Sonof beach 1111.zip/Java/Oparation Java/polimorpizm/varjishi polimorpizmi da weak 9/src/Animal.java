public abstract class Animal implements AnimalInt{
    String name;

    abstract void grow();
}
