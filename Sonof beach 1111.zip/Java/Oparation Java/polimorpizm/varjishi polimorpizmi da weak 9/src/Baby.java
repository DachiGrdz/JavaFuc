public class Baby extends Person{
    void cry(){
        System.out.println(firstname+" "+lastname+" is crying....    ");
    }

    @Override
    void speak() {
        System.out.println("Babies cant speak....... ");
    }
}
