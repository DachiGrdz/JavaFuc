public interface Notification {
    void send();

    void receive();
}
