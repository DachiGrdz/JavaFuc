public class Main {
    public static void main(String[] args) {
        Email e1=new Email("Mail@gmail.com","Mail@gmail.ru","გამარჯობა როგორ ბრძანდებით");
        e1.send();
        e1.receive();

        System.out.println("-----------------------");

        SMS s1=new SMS("15656564", "365541236","ფასდაკლებაა ბოშის ტექნიკაზე");
        s1.receive();
        s1.send();
    }
}