public class Email implements Notification{
    public String Semail;
    public String Remail;
    public String Text;

    Email(String Semail, String Remail, String Text){
        this.Semail=Semail;
        this.Remail=Remail;
        this.Text=Text;
    }
    @Override
    public void send() {
        System.out.println("მიმღები იმეილი: "+Remail);
        System.out.println("მეილი: "+Text);
    }

    @Override
    public void receive() {
        System.out.println("გამგზავნი იმეილი: "+Semail);
    }
}
