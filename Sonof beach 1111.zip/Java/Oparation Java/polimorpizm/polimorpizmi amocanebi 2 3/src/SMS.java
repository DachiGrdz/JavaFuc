public class SMS implements Notification{
    public String Snumber;
    public String Rnumber;
    public String Text;

    SMS(String Snumber, String Rnumber, String Text){
        this.Snumber=Snumber;
        this.Rnumber=Rnumber;
        this.Text=Text;
    }

    @Override
    public void receive() {
        System.out.println("ტექსტი: "+Text);
        System.out.println("მიმღებუ ნომერი: "+Rnumber);
    }

    @Override
    public void send() {
        System.out.println("გამგზავნი ნომერი: "+Snumber);
    }
}
