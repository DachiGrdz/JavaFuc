public class Student extends Person {

    private double avgScore;
    private String email;
    private String faculty;


    public Student(double avgScore, String email, String faculty, String idNum, String name, String lastName, int age) {
        this.avgScore = avgScore;
        this.email = email;
        this.faculty = faculty;
        this.idNum = idNum;
        this.name = name;
        this.lastName = lastName;
        this.age = age;
    }


    public double getAvgScore() {
        return avgScore;
    }

    public String getEmail() {
        return email;
    }

    public String getFaculty() {
        return faculty;
    }

    @Override
    public void printInfo() {
        System.out.println("პირადი ნომერი " + this.idNum);
        System.out.println("სახელი " + this.name);
        System.out.println("გვარი " + this.lastName);
        System.out.println("საშუალო ქულა " + this.avgScore);
        System.out.println("იმეილი " + this.email);
        System.out.println("ფაკულტეტი " + this.faculty);
        System.out.println("ასაკი " + this.age);
    }
}
