public abstract class Person {

    protected String idNum;
    protected String name;
    protected String lastName;
    protected int age;

    public abstract void printInfo();
}
