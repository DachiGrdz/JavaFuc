public class Lecturer extends Person {

    private String xarisxi;
    private int years;

    public Lecturer(String xarisxi, int years, String idNum, String name, String lastName, int age) {
        this.xarisxi = xarisxi;
        this.years = years;
        this.idNum = idNum;
        this.name = name;
        this.lastName = lastName;
        this.age = age;
    }

    public String getXarisxi() {
        return xarisxi;
    }

    public int getYears() {
        return years;
    }

    @Override
    public void printInfo() {
        System.out.println("სახელი " + this.name);
        System.out.println("გვარი " + this.lastName);
        System.out.println("პირადი ნომერი " + this.idNum);
        System.out.println("ლექტორის ხარისხი " + this.xarisxi);
        System.out.println("სამუშაო გამოცდილება " + this.years);
        System.out.println("ასაკი " + this.age);
    }
}