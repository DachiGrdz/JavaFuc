import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        String saxeli;
        String gvari;
        String idNum;
        double avgScore;
        int years;
        String xarisxi;
        String email;
        String faculty;
        int age;

        Scanner scanner = new Scanner(System.in);

        Student[] studentArr = new Student[5];
        Lecturer[] lecturerArr = new Lecturer[5];

        System.out.println("შემოიტანეთ სტრუდენტის მოანცემები");


        for (int i = 0; i < studentArr.length; i++) {

            System.out.println("პირადი ნომერი");
            idNum = scanner.next();
            System.out.println("სახელი ");
            saxeli = scanner.next();
            System.out.println("•გვარი");
            gvari = scanner.next();
            System.out.println("იმეილი");
            email = scanner.next();
            System.out.println("ფაკულტეტი");
            faculty = scanner.next();
            System.out.println("საშუალო ქულა");
            avgScore = scanner.nextDouble();
            System.out.println("ასაკი");
            age = scanner.nextInt();

            Student student = new Student(avgScore, email, faculty, idNum, saxeli, gvari, age);

            studentArr[i] = student;

        }

        System.out.println();
        System.out.println("შემოიტანეთ ინფორმაცია ლექტორების შესახებ");

        for (int i = 0; i < lecturerArr.length; i++) {

            System.out.println("პირადი ნომერი");
            idNum = scanner.next();
            System.out.println("სახელი ");
            saxeli = scanner.next();
            System.out.println("•გვარი");
            gvari = scanner.next();
            System.out.println("ასაკი");
            age = scanner.nextInt();
            System.out.println("ლექტორის ხარისხი");
            xarisxi = scanner.next();
            System.out.println("სამუშაო გამოცდილება");
            years = scanner.nextInt();

            Lecturer lecturer = new Lecturer(xarisxi, years, idNum, saxeli, gvari, age);

            lecturerArr[i] = lecturer;
        }

        System.out.println();


        Student maxStudent = studentArr[0];

        for (int i = 0; i < studentArr.length; i++) {

            if (studentArr[i].getAvgScore() > maxStudent.getAvgScore()) {

                maxStudent = studentArr[i];
            }
        }


        Lecturer maxLecturer = lecturerArr[0];

        for (int i = 0; i < lecturerArr.length; i++) {

            if (lecturerArr[i].getYears() > maxLecturer.getYears()) {
                maxLecturer = lecturerArr[i];
            }
        }


        System.out.println();
        System.out.println("მაქსიმალური საშუალო ქულის მქონე სტუდენტი:");
        maxStudent.printInfo();
        System.out.println();
        System.out.println("მაქსიმალური გამოცდილების მქონე ლექტორია");
        maxLecturer.printInfo();

    }
}