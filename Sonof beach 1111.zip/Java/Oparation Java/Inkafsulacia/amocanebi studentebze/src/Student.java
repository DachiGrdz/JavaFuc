public class Student {
    public String name;
    public int age;
    public int course;
    public double avs;

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public int getAge() {
        return age;
    }

    public void setCourse(int course) {
        this.course = course;
    }
    public double getCourse() {
        return course;
    }

    public void setAvs(double avs){
        this.avs=avs;
    }
    public double getAvs(){
        return avs;
    }
}
