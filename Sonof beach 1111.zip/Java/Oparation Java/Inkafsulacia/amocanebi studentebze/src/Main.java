import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Student[] student=new Student[5];

        for(int i=0; i<5; i++){
            student[i] = new Student();
            student[i].setName(scanner.nextLine());
            student[i].setAge(scanner.nextInt());
            student[i].setCourse(scanner.nextInt());
            student[i].setAvs(scanner.nextDouble());
            scanner.nextLine();
        }
        double mxs=student[0].getAvs();
        int c=0;
        for(int i=1; i<5; i++){
            if(mxs<student[i].getAvs()){
                mxs=student[i].getAvs();
                c++;
            }
        }
        System.out.println("Student With HighestScore");
        System.out.println("Name: "+student[c].getName());
        System.out.println("Age: "+student[c].getAge());
        System.out.println("Course: "+student[c].getCourse());
        System.out.println("Score: "+student[c].getAvs());

        Lesson[] lessons=new Lesson[5];

        for(int i=0; i<5; i++){
            lessons[i]=new Lesson();
            lessons[i].setLname(scanner.nextLine());
            lessons[i].setSnumber(scanner.nextInt());
            lessons[i].setWnumber(scanner.nextInt());

            scanner.nextLine();
        }

        double chawrilebi=lessons[0].Chawr(lessons[0].getSnumber(),lessons[0].getWnumber());
        int c1=0;
        for(int i=1; i<5; i++){
            if(chawrilebi<lessons[i].Chawr(lessons[i].getSnumber(),lessons[i].getWnumber())){
                chawrilebi=lessons[i].Chawr(lessons[i].getSnumber(),lessons[i].getWnumber());
                c1++;
            }
        }
        System.out.println("ყველაზე რთული საგანი: "+lessons[c1].getLname());
    }
}