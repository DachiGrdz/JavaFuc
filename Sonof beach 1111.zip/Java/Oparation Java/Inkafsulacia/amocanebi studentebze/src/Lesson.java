public class Lesson {
    public String Lname;
    public int Snumber;
    public int Wnumber;

    public void setLname(String Lname){
        this.Lname=Lname;
    }
    public String getLname(){
        return Lname;
    }

    public void setSnumber(int snumber) {
        Snumber = snumber;
    }
    public int getSnumber() {
        return Snumber;
    }

    public void setWnumber(int wnumber) {
        Wnumber = wnumber;
    }

    public int getWnumber() {
        return Wnumber;
    }

    public double Chawr(int Snumber, int Wnumber){
        return (double) ((Snumber - Wnumber) /Snumber)*100;
    }
}
