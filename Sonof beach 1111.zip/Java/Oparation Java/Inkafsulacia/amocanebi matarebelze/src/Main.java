import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Train[] trains=new Train[5];

        for(int i=0; i<5; i++) {
            trains[i] = new Train();
            trains[i].setinfo(scanner.nextInt(),scanner.nextInt(),scanner.nextInt(),scanner.nextInt(),scanner.nextInt());
        }


        Train max = trains[0];
        for (int i = 0; i < trains.length; i++) {

            if (trains[i].tanxa() > max.tanxa()) {
                max = trains[i];
            }
        }

        System.out.println("მაქსიმალური მოგების მქონე მატარებელია:");
        max.printinfo();
    }
}