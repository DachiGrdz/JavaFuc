public class Train {
    private int cnumber;
    private int pnumber;
    public int tprice;
    public int sticket;
    public int tnumber;

    public int profite;

    public int setinfo(int cnumber, int pnumber, int tprice, int sticket, int tnumber){
        this.cnumber=cnumber;
        this.pnumber=pnumber;
        this.tprice=tprice;
        this.sticket=sticket;
        this.tnumber=tnumber;
        return 0;
    }
    public double tanxa() {
        return tprice * sticket;
    }
    void printinfo(){
        System.out.println(cnumber+" "+pnumber+" "+tprice+" "+sticket+" "+tnumber);
    }


}
