public class shape {
    private static final double pi=3.14;
    public static double perimets(int a1, int a2, int a3){
        return a1+a2+a3;
    }

    public static double perimets(int a1, int a2, int a3, int a4){
        return a1+a2+a3+a4;
    }

    public static double perimets(int a1, int a2, int a3, int a4, int a5, int a6){
        return a1+a2+a3+a4+a5+a6;
    }

    public static double circlArea(double r){
        return pi*r*r;
    }

    public static double circle(double r){
        return 2*pi*r;
    }


}
