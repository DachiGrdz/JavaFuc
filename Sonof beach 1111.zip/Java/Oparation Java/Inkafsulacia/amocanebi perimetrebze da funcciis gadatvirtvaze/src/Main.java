public class Main {
    public static void main(String[] args) {
        System.out.println("ოთხკუთხედის პერიემტრია "+shape.perimets(1,2,3,4));
        System.out.println("სამკუთხედის პერიმეტრია "+shape.perimets(1,2,3));
        System.out.println("ექვსკუთხედის პერიმეტრია "+shape.perimets(1,2,3,4,5,6));
        System.out.println("წრის ფართობია  "+shape.circlArea(4));
        System.out.println("წრეწირის სიგრძეა "+shape.circle(4));
    }
}