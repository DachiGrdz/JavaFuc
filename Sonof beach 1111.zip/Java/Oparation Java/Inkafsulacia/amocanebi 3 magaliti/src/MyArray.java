public class MyArray {
    private int[] arr;

    public void setArr(int[] arr) {
        this.arr = arr;
    }
    public int[] getArr() {
        return arr;
    }

    public void kent(){
        int kentebi=0;
        int raodenoba=0;
        for(int i=0; i< arr.length; i++){
            if(i%2!=0){
                kentebi+=arr[i];
                raodenoba++;
            }
        }
        System.out.println("კენტ ინდექსზე მდგომი კენტი რიცხვების საშუაოლოა: "+kentebi/raodenoba);
    }
}
