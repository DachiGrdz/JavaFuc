import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random=new Random();
        int[][] arr= new int[4][4];

        for(int i=0; i<arr.length; i++){
            for(int j=0; j<arr.length; j++){
                arr[i][j]= random.nextInt(100);
            }
        }
        MyArray myArray=new MyArray();
        myArray.setArr(arr);
        myArray.LK();
    }
}