public class MyArray {
    private int[][] arr;

    public int[][] getArr(){
        return arr;
    }

    public void setArr(int[][] arr) {
        this.arr = arr;
    }

    public void LK(){
        int luw=0;
        int ken=0;
        for(int i=0; i< arr.length; i++){
            for(int j=0; j< arr.length; j++){
                if(arr[i][j]%2==1){
                    ken++;
                }if(arr[i][j]%2==0){
                    luw++;
                }
            }
        }
        if(luw>ken){
            System.out.println("ლუწების რაოდენობა მეტია: "+luw);
        }else{
            System.out.println("კენტების რაოდენობა მეტია: "+ken);
        }
    }
}
