public class Lector {
    private String name;
    private String srname;
    private int number;
    private String status;

    public void setName(String name) {this.name = name;}
    public void setSrname(String srname) {this.srname = srname;}
    public void setNumber(int number) {this.number = number;}
    public void setStatus(String status) {this.status = status;}

    public String getName() {return name;}
    public String getSrname() {return srname;}
    public int getNumber() {return number;}
    public String getStatus() {return status;}

    public void std(){

    }
}
