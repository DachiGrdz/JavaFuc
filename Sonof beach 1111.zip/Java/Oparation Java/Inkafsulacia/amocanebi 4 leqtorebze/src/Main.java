import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Lector[] lactor=new Lector[5];

        for(int i=0; i< lactor.length; i++){
            lactor[i]=new Lector();
            lactor[i].setName(scanner.nextLine());
            lactor[i].setSrname(scanner.nextLine());
            lactor[i].setNumber(scanner.nextInt());
            lactor[i].setStatus(scanner.nextLine());
            scanner.nextLine();
        }



    }
}