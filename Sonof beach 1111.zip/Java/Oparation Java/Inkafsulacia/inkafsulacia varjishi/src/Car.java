public class Car {
    private String firm;
    private String model;
    private String carNumber;
    private int wheelcount;

    public void setFirm(String firm) {
        this.firm = firm;
    }
    public String getFirm() {
        return firm;
    }

    public void setModel(String model) {
        this.model = model;
    }
    public  String getModel(){
        return  model;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }
    public String getCarNumber(){
        return carNumber;
    }

    public void setwheelcount(int wheelcount){
        if(wheelcount<=0) {
            System.out.println("საბურავების რაოდენობა უნდა იყოს დადებითი რიცხვი");
        }else{
            this.wheelcount=wheelcount;
        }
    }
    public int getWheelcount(){
        return wheelcount;
    }

    /////////////////////
    //static wevrebi
    public static int x;

    public static int num(int a, int b){
        return a+b;
    }

    /////////////////////////////////////////
    //metodebis gadatvirtva
    public int sum(int i, int j){
        return i+j;
    }

    public int sum(int i, int j, int k){
        return i+j+k;
    }

}
