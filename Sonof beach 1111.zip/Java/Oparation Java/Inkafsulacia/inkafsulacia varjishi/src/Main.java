//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Car c=new Car();
        c.setFirm("BMW");
        c.setModel("M5");
        c.setCarNumber("GG-123-GG");
        c.setwheelcount(4);

        System.out.println(c.getFirm());
        System.out.println(c.getModel());
        System.out.println(c.getCarNumber());
        System.out.println(c.getWheelcount());

        Car c2=new Car();
        c.setwheelcount(-2);

        Car t1=new Car();
        t1.x=35;
        System.out.println(t1.x);
        Car t2=new Car();
        t1.x++;
        System.out.println(t2.x);

        int result=Car.num(5,7);
        System.out.println(result);

        ///////////////////////////////////////////
        ////////metodebis gadatvirtva
        Car m1=new Car();
        int sum1=m1.sum(4,9);
        int sum2=m1.sum(1,9,26);
        System.out.println("Sum1= "+sum1);
        System.out.println("Sum2= "+sum2);
    }
}