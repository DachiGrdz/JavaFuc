public class Wiladi {

    private int mricxveli;
    private int mnishvnelil;

    public Wiladi(int mricxveli, int mnishvnelil) {
        this.mricxveli = mricxveli;
        this.mnishvnelil = mnishvnelil;
    }

    public int getMricxveli() {
        return mricxveli;
    }

    public int getMnishvnelil() {
        return mnishvnelil;
    }

    @Override
    public String toString() {
        return "Wiladi{" +
                "mricxveli=" + mricxveli +
                ", mnishvnelil=" + mnishvnelil +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        Wiladi t = (Wiladi) obj;
        return (this.mricxveli * t.mnishvnelil == t.mricxveli * this.mnishvnelil);
    }
}
