package pk2;

public class class2 {


}
