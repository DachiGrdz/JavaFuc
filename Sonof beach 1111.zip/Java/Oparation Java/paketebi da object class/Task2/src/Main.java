import pk1.Test;

import java.util.Random;
import  java.lang.Math;

public class Main {
    public static void main(String[] args) {

        pk1.Test test1 = new pk1.Test();
        pk2.Test test2 = new pk2.Test();


        pk1.class1 a = new pk1.class1();





        Wiladi[] arr = new Wiladi[5];

        Random random = new Random();

        for (int i = 0; i < arr.length; i++) {

            int mricxveli = random.nextInt(5);
            int mnishvneli = (random.nextInt(5) + 1);


            Wiladi t = new Wiladi(mricxveli, mnishvneli);

            arr[i] = t;

        }

        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }

        System.out.println("-------");

        int cnt = 0;

        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {

                if (arr[i].equals(arr[j])) {
                    System.out.println(arr[i] + " == " + arr[j]);
                    cnt++;
                }

            }
        }

        System.out.println("მასივში ერთმანეთის ტოლი წილადების რაოდენობაა " + cnt);

    }
}
