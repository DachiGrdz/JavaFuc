import java.util.Scanner;
import java.lang.Math;

public class Main {
    public static void main(String[] args){
        Writer[] w1= new Writer[3];
        Scanner scanner=new Scanner(System.in);

        for(int i=0; i< w1.length; i++){
            w1[i]=new Writer();
            System.out.println("შეიყვანეთ სახელი: ");
            w1[i].name=scanner.nextLine();
            System.out.println("შეიყვანეთ გვარი: ");
            w1[i].lastname=scanner.nextLine();
        }

        for(int i=0; i< w1.length; i++){
            System.out.println(w1[i].toString());
        }


        Book[] books=new Book[3];

        for (int i=0; i< books.length; i++){
            books[i]=new Book();
            System.out.println("შეიყვანეთ წიგნის სახელი: ");
            books[i].bname=scanner.nextLine();
            System.out.println("შეიყვანეთ გვერდების რაოდენობა: ");
            books[i].page=scanner.nextInt();
            scanner.nextLine();
            System.out.println("შეიყვანეთ აუტორის: ");
            books[i].authottype=scanner.nextLine();
            System.out.println("შეიყვანეთ ჟანრი: ");
            books[i].janri=scanner.nextLine();
        }

        System.out.println(books[0].equals(books[2]));

        for(int i=0; i< books.length; i++){
            books[i].toString();
        }
    }
}