public class Book {
    String bname;
    int page;
    String janri;
    String authottype;

    @Override
    public boolean equals(Object obj) {
        if(obj==null){
            return false;
        }
        Book prs=(Book)obj;
        if(prs.page==this.page) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return page*12;
    }

    @Override
    public String toString() {
        return bname+" "+janri+" "+authottype+" "+page;
    }
}
