//public class B {
//    public int y;
//    public B(int x, int y){
//        this.y=y;
//        super(x);
//    }
//
//}
