//public class Main {
//    public static void main(String[] args){
//        B b=new B(13,7);
//        System.out.println(b.x+b.y);
//    }
//}
