//public class A {
//    //mexute
//    private int x;
//    public void setX(int x){
//        this.x=x;
//    }
//
//
//    //3 da 4
//    //    public int x;
//}
