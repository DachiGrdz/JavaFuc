//public class B extends A{
//mexute
//    public int y;
//    public int sum(){
//        return x+y;
//    }
//}
