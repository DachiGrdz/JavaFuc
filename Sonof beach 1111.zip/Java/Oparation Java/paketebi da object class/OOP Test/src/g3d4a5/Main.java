//public class Main {
//
//    public static void f1(int x){
//        x++;
//    }
//
//    public static void f2(A a){
//        a.x++;
//    }
//
//    public static void main(String[] args){
//        A a=new A();
//        a.x=10;
//        int x=10;
//        f1(x);
//        f2(a);
//        System.out.println(x+" "+a.x);
//
//
//
//        //mesame magaliti g pasuxi
//        //A a1=new A();
////        a1.x=10;
////        A a2=new A();
////        a2.x=10;
////        //es if amowmebs ertidaigive adgils ikavebs tu ara a1 da a2
////        //
////        if(a1==a2){
////            System.out.println("ranairad gamovida");
////        }else{
////            System.out.println("es vafshe ratom");
////        }
//    }
//}
