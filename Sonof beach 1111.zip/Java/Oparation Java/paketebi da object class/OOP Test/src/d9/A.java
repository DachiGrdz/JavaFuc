//public class A {
//    public int x;
//    public A(){}
//    public A(int x){
//        this.x=x;
//    }
//}
