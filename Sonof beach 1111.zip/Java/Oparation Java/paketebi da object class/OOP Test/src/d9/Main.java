//public class Main {
//    public static void main(String[] args){
//        A a=new A(13);
//        B b=new B();
//        b.x=7;
//        System.out.println(a.x+b.x);
//    }
//}
