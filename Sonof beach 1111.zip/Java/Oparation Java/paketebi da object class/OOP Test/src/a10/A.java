/*
public class A {
    //abstract metodidan ranairad wamovigo amixseni
    public abstract void f(){
        System.out.println("A");
    }
}
*/
