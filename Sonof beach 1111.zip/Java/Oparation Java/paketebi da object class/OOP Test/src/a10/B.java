//public class B extends A{
//    @Override
//    public void f() {
//        System.out.println("B");
//    }
//}
