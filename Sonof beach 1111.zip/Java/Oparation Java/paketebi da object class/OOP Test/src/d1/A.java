//package d1;
//public class A {
//    int x;
//    int f(int a){
//        return a+this.x;
//    }
//}
