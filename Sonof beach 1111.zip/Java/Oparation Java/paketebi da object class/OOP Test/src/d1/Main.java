//package d1;
//
//public class Main {
//    public static void main(String[] args) {
//        A a= new A();
//        a.x=2;
//        System.out.println(a.f(3));
//    }
//}