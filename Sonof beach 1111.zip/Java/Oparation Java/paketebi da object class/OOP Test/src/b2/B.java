//public class B {
//    public int y;
//    public A a;
//}
