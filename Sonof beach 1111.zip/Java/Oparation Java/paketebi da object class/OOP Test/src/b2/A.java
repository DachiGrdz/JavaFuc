//public class A {
//    public int x;
//    public B b;
//}
