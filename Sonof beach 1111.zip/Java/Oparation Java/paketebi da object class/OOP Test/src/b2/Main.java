//public class Main {
//    public static void main(String[] args){
//        A a=new A();
//        a.x=10;
//        B b=new B();
//        b.y=11;
//        b.a=a;
//        a.b=b;
//        System.out.println(a.b.a.x);
//    }
//}
