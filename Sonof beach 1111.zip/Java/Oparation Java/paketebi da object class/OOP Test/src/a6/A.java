//public final class A {
//    public int x;
//    public A(int x){
//        this.x=x;
//    }
//}
