//public class B extends A{
//    //ar shegvizdlia finalidan memkvidreobis gaketeba
//}
