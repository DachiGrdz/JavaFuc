//public class Main {
//    A a=new C();
//    B b=new A();
//    C c=new A();
//}
