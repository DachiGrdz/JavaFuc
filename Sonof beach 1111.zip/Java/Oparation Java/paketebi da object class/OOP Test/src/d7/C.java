//public class C extends B{
//    public int z;
//}
////A a = new C();: This line demonstrates polymorphism. It creates an instance of class C, which is a subclass of B, and assigns it to a reference of type A. This is valid because Java allows a subclass instance to be treated as an instance of its superclass.
//
////B b = new A();: This line is not valid. It tries to create an instance of class A and assign it to a reference of type B. Since B is a subclass of A, you cannot assign an instance of A to a reference of type B. This will result in a compilation error.