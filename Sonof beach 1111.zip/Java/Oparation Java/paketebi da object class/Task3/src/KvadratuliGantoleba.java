public class KvadratuliGantoleba {

    private double a;
    private double b;
    private double c;
    private double x1;
    private double x2;

    public KvadratuliGantoleba(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;


        double d = Math.pow(b, 2) - 4 * a * c;

        if (d >= 0) {

            x1 = (-b + Math.sqrt(d)) / (a * a);
            x2 = (-b - Math.sqrt(d)) / (a * a);
        } else {

            System.out.println("განტოლებს ამონახსნი არ აქვს");

        }
    }

    @Override
    public boolean equals(Object obj) {
        KvadratuliGantoleba gantoleba = (KvadratuliGantoleba) (obj);

        return (this.x1 == gantoleba.x1 || this.x1 == gantoleba.x2) && (this.x2 == gantoleba.x1 || this.x2 == gantoleba.x2);
    }

    @Override
    public String toString() {return a + " " + b + " " + c + " " + x1 + " " + x2;}
}
