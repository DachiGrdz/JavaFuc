public class Main {
    public static void main(String[] args) {


        KvadratuliGantoleba gantoleba = new KvadratuliGantoleba(5,15,6);
        KvadratuliGantoleba gantoleba1 = new KvadratuliGantoleba(2,18,6);


        System.out.println(gantoleba);
        System.out.println(gantoleba1);
        if(gantoleba.equals(gantoleba1)){

            System.out.println("განტოლებები ტოლფასია");

        }else{

            System.out.println("განტოლებები არ არის ტოლფასი");

        }


    }
}
