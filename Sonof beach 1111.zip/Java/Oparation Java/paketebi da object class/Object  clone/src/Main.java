public class Main {
    public static void main(String[] args) throws CloneNotSupportedException{
        Person p1 = new Person();
        p1.fisrtName="დაჩი";
        p1.lastName="გრძელიშვილი";
        p1.idnum="010101001";
        p1.age=25;
        System.out.println(p1.fisrtName+" "+p1.lastName+" "+p1.age);

        Person p2=(Person)p1.clone();
        System.out.println(p2.fisrtName+" "+p2.lastName+" "+p2.age);

        Person p3 = new Person();
        p3.fisrtName="დაჩი";
        p3.lastName="გრძელიშვილი";
        p3.age=25;
        p3.idnum="56025456";

        //equals
        System.out.println(p1.equals(p3));

        p3.idnum="010101001";
        System.out.println(p1.equals(p3));

        //hashCode
        System.out.println(p3.hashCode());

        //toString
        System.out.println(p3.toString());
        System.out.println("--------------------------");

        //Wrapper classes
        System.out.println(Integer.MAX_VALUE);//int ის მაქსიმალური მნიშვნელობა
        System.out.println(Integer.MIN_VALUE);//int ის მინიმალური მნიშვნელობა
        System.out.println(Integer.SIZE);//მეხსიერების ზომა ბაიტებში
        System.out.println(Integer.parseInt("2565"));//სტრიქონების გარდაქმნა რიცხვებად
        System.out.println(Integer.toBinaryString(38));//რიცხვის ორობითი მეთოდი
    }
}
