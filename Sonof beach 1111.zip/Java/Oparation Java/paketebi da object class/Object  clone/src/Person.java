public class Person {
    String fisrtName;
    String lastName;
    String idnum;
    int age;

    @Override
    protected Object clone(){
        Person clonePerson=this;
        return clonePerson;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj==null){
            return false;
        }

        // Cast the object to the type of the class (Person in this case)
        Person prs=(Person)obj;

        // Compare the idnum of the current instance with the idnum of the other object
        if(prs.idnum==this.idnum) {
            return true;  // Objects are considered equal if idnum is the same
        }

        return false;  // Objects are not equal if idnum is different
    }

    @Override
    public int hashCode(){
        return this.age*12;
    }

    //მას შემდეგ  რაც კლასში გადავფარავთ toString() მეთოდს,
    // შეგვიძლია მისი ობიექტი  პირადპირ გამოვიყენოთ System.out.println() ის პარამეტრად.

    public String toString(){
        return fisrtName+" "+lastName+" "+age+" "+idnum;
    }
}
