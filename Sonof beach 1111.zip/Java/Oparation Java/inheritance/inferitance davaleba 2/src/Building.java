public class Building {
    private int floor;
    private int door;
    private int windows;
    public Building(){}

    public Building(int floor, int door, int windows){
        this.floor=floor;
        this.door=door;
        this.windows=windows;
    }

    public int getDoor() {return door;}
    public int getFloor() {return floor;}
    public int getWindows() {return windows;}

    public void getinfo(){
        System.out.println(floor+" "+door+" "+windows);
    }


}
