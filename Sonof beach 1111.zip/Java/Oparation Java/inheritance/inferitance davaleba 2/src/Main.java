import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Building[] buildings=new Building[5];

        for(int i=0; i<buildings.length; i++){
            System.out.println("sheiyvanet "+(i+1)+" shenobis monacemebi");
            buildings[i]=new Building(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
        }

        House[] houses=new House[5];

        for(int i=0; i<houses.length; i++){
            System.out.println("sheiyvanet "+(i+1)+" saxlis monacemebi");
            houses[i]=new House(scanner.nextInt(), scanner.nextInt(), scanner.nextInt(),scanner.nextInt(),scanner.nextInt());
        }
        for(int i=0; i<buildings.length; i++){
            buildings[i].getinfo();
        }
        for(int i=0; i<houses.length; i++){
            houses[i].get();
        }
    }
}