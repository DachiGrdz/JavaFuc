public class House extends Building {
    private int rooms;
    private int squar;

    public House(int floor, int door, int windows, int rooms, int squar){
        super(floor,door,windows);
        this.rooms=rooms;
        this.squar=squar;
    }

    public int getRooms() {
        return rooms;
    }
    public int getSquar() {
        return squar;
    }
    public void get(){
        System.out.println(super.getDoor()+" "+super.getFloor()+" "+super.getWindows()+" "+rooms+" "+squar);
    }
}
