public class Baby extends Person{
//pirveli ori magaliti
//    public Baby(String firstname, String lastname, String idnum, int age){
//        super(firstname, lastname,idnum,age);
//    }
//    void cry(){
//        System.out.println(firstname+" "+lastname+" bavshvi tiris");
//    }

    //private wevrebis gamozdaxeba aq sawiroa get metodi gamovizdaxot superit radgan es
    //wvdomas mogvcems cvladze
    public Baby(String firstname, String lastname, String idnum, int age){
        super(firstname, lastname,idnum,age);
    }
    void cry(){
        System.out.println(super.getFirstname()+" "+super.getLastname()+" is crying...    ");
    }

}
