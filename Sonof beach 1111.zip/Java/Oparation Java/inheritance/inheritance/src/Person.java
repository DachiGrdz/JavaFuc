public class Person {
//pirveli ori magaliti
    //    String firstname;
//    String lastname;
//    String idnum;
//    int age;
//
//
//    public Person(String firstname, String lastname,String idnum, int age){
//        this.firstname=firstname;
//        this.lastname=lastname;
//        this.idnum=idnum;
//        this.age=age;
//    }
//
//    void eat(){
//        System.out.println(firstname+" "+lastname+" wams sawmels");
//    }
//
//    void walk(){
//        System.out.println(firstname+" "+lastname+" bevrs dadis es kaci");
//    }

    //mesame private wevrebze mushaoba
    private String firstname;
    private String lastname;
    private String idnum;
    private int age;

    public Person(String firstname, String lastname, String idnum, int age){
        this.firstname=firstname;
        this.lastname=lastname;
        this.idnum=idnum;
        this.age=age;
    }

    public void setFirstname(String firstname) {this.firstname = firstname;}
    public String getFirstname() {return firstname;}
    public void setLastname(String lastname) {this.lastname = lastname;}
    public String getLastname() {return lastname;}
    public void setIdnum(String idnum) {this.idnum = idnum;}
    public String getIdnum() {return idnum;}
    public void setAge(int age) {this.age = age;}
    public int getAge() {return age;}

    void eat(){
        System.out.println(firstname+" "+lastname+" is eating...  ");
    }
    void walk(){
        System.out.println(firstname+" "+lastname+" is eating...   ");
    }

}
