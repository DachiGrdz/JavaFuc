public class Main {
    public static void main(String[] args) {
        //constructorebis gareshe
        //        Person p1=new Person();
//        p1.firstname="Dachi";
//        p1.lastname="Grdzelishvili";
//
//        p1.walk();
//        p1.eat();
//        //p1.cry(); es kodi ar imushavebs radgan p1 obieqts ar aqvs wvdoma shvil klasis metodze
//        //velebi imitom miigo Baby klasma rom yvela veli publicze eyena private rom yofiliyo
//        // ar gamovidoda ase martivad
//        Baby b1=new Baby();
//        b1.firstname="dachi";
//        b1.lastname="grdzelishvili";
//
//        b1.eat();
//        b1.walk();
//        b1.cry();

        //constructorit
//        Baby b=new Baby("mari","grdzelishvili","14512063",1);
//        b.eat();
//        b.walk();
//        b.cry();

        Baby b=new Baby("dachi","grdzishvili","45665as323",19);

        b.eat();
        b.walk();
        b.cry();
    }
}