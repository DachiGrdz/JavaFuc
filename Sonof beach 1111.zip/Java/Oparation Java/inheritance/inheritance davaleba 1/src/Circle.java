public class Circle extends Point{
    private double r;
    public Circle(double x, double y, double r){
        super(x,y);
        this.r=r;
    }
    public double getR() {
        return r;
    }
    static double pi=3.14;
    public void radius(){
        System.out.println("Wris radiusi: "+2*pi*getR());
    }
    public void lenght(){
        System.out.println("Wris sigrdze: "+pi*getR()*getR());
    }
}
