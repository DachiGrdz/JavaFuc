import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Circle[] circles=new Circle[5];

        for(int i=0; i< circles.length; i++){
            circles[i]=new Circle(scanner.nextDouble(),scanner.nextDouble(),scanner.nextDouble());
        }
        for(int i=0; i< circles.length; i++){
            circles[i].radius();
            circles[i].lenght();
        }
    }
}