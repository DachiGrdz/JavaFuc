import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Cars[] c1=new Cars[3];

        int mx=0;
        for(int i=0; i< c1.length; i++){
            c1[i]=new Cars();
            System.out.println("მანქანის კომპანია ");
            c1[i].setCompany(scanner.nextLine());
            System.out.println("მოდელი");
            c1[i].setModel(scanner.nextLine());
            System.out.println("სახელმწიფო ნომერი");
            c1[i].setNumber(scanner.nextLine());
            System.out.println("ცილინდრების რაოდენობა");
            c1[i].getCarEngine().setCylindrnumber(scanner.nextInt());
            System.out.println("რესურსი რამდენი კილომეტრის გავლა შეუძლია ძრავს ");
            c1[i].getCarEngine().setKmcan(scanner.nextInt());
            System.out.println("საწვავის ტიპი");
            c1[i].getCarEngine().setOiltype(scanner.nextLine());
            scanner.nextLine();
        }

        mx=c1[0].getCarEngine().getKmcan();
        int k=0;
        for(int i=1; i< c1.length; i++){
            if(c1[i].getCarEngine().getKmcan()>mx){
                mx=c1[i].getCarEngine().getKmcan();
                k=i;
            }
        }
        c1[k].getCarEngine().printInfo();

    }
}