public class Cars {
    private String company;
    private String model;
    private String number;
    private engine carEngine;  // Added a reference to the Engine class

    public void setNumber(String number) {this.number = number;}
    public void setModel(String model) {this.model = model;}
    public void setCompany(String company) {this.company = company;}

    // Constructor for Cars class to initialize the Engine instance
    public Cars() {
        this.carEngine = new engine();
    }
    public engine getCarEngine() {
        return carEngine;
    }

    public class engine{
        private String oiltype;
        private int Cylindrnumber;
        private int kmcan;

        public void setCylindrnumber(int cylindrnumber) {Cylindrnumber = cylindrnumber;}
        public void setOiltype(String oiltype) {this.oiltype = oiltype;}
        public void setKmcan(int kmcan) {this.kmcan = kmcan;}

        public int getKmcan() {return kmcan;}

        public void printInfo(){
            System.out.println("მონაცემები მაქსიმალური შესაძლებლობის მქონდე მანქანაზე");
            System.out.println("კომპანია: "+Cars.this.company);
            System.out.println("მოდელი: "+Cars.this.model);
            System.out.println("ნომერი: "+Cars.this.number);
            System.out.println("საწვავის ტიპი: "+oiltype);
            System.out.println("ცილინდრების რაოდენობა: "+Cylindrnumber);
            System.out.println("რესურსი რამდენი\n"+"კილომეტრის გავლა შეუძლია ძრავს: "+kmcan);
        }
    }
}
