public class Library {
    private String id;
    private String name;

    public void printinfo(){
        class book{
            private String bookid;
            private String bookname;
        }
        System.out.println(id);
        System.out.println(name);
    }
}
