import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        Universities uni1=new Universities("საქართველოს უნივერსიტეტი","კერძო",27);
        uni1.printInfo();

        Universities.Student stu1=uni1.new Student("დაჩი","გრძელიშვილი",19,"56841585486", 3.99, "ინჟინერია");
        stu1.printInfo();
    }
}