public class Universities {
    private String Uniname;
    private String status;
    private int coursenumber;

    Universities(){}

    Universities(String Uniname, String status, int coursenumber){
        this.Uniname=Uniname;
        this.status=status;
        this.coursenumber=coursenumber;
    }

    public void printInfo(){
        System.out.println("უნივერსიტეტის ინფორმაცია");
        System.out.println("უნივერსიტეტის სახელი: "+Uniname);
        System.out.println("უნივესიტეტის სტატუსი: "+status);
        System.out.println("კურსების რაოდენობა: "+coursenumber);
        System.out.println("-------------------------------------------");
    }

    public class Student{
        private String name;
        private String Lname;
        private int age;
        private String idnum;
        private double GPA;
        private String course;

        Student(String name, String Lname, int age, String idnum, double GPA, String course){
            this.name=name;
            this.Lname=Lname;
            this.age=age;
            this.idnum=idnum;
            this.GPA=GPA;
            this.course=course;
        }

        public void printInfo(){
            System.out.println("სტუდენტის შესახებ ინფორმაცია");
            System.out.println("უნივერსიტეტის სახელი: "+Universities.this.Uniname);
            System.out.println("უნივესიტეტის სტატუსი: "+Universities.this.status);
            System.out.println("კურსების რაოდენობა: "+Universities.this.coursenumber);
            System.out.println("სახელი: "+name);
            System.out.println("გვარი: "+Lname);
            System.out.println("ასაკი: "+age);
            System.out.println("პირადი ნომერი: "+idnum);
            System.out.println("საშუალო ქულა: "+GPA);
            System.out.println("კურსის დასახელება: "+course);
            System.out.println("--------------------------------------------");
        }
    }
}
