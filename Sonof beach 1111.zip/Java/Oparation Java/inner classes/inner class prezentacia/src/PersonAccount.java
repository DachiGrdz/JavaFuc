public class PersonAccount {
    private String accountNumber;
    private String bankname;
    private double balance;

    public PersonAccount(){};

    //es aris localuri classi romlis implementacia aris metodis tanshi
    //aseti clasis sheqmna mxolod shsaZdlebelia metodis tanshi da mis garet ar chans
    public void number(int n){
        class classb{
            void f(){
                for(int i=0; i<n; i++){
                    System.out.println(i);
                }
            }
        };
        classb b1=new classb();
        b1.f();
    }

    public class PlasticCard{
        private String cardNumber;
        private String CardType;
        private String cardPincode;

        public void printInfo(){
            //pirvel samshi outer classis obiectebs mivwvdit
            //nested class ar aqvs aranairi wvdoma gare klastan rac nishnavs imas rom pirvel sams ver davwert radgan ver miwvdeba
            //xolo nested classi ki aris igive rac static class anu statikuri
            System.out.println("Account number = "+PersonAccount.this.accountNumber);
            System.out.println("Bank name = "+PersonAccount.this.bankname);
            System.out.println("Balance = "+PersonAccount.this.balance);
            System.out.println("Card number = "+cardNumber);
            System.out.println("Card Type = "+CardType);
            System.out.println("Card Pincode = "+cardPincode);
        }
        public PlasticCard(String cardNumber, String cardType, String cardPincode){
            this.cardNumber=cardNumber;
            this.cardPincode=cardPincode;
            this.CardType=cardType;
        }

    }

    public PersonAccount(String accountNumber, String bankname, double balance){
        this.accountNumber=accountNumber;
        this.bankname=bankname;
        this.balance=balance;
    }

    public void setAccountNumber(String accountNumber) {this.accountNumber = accountNumber;}
    public String getAccountNumber() {return accountNumber;}

    public void setBankname(String bankname) {this.bankname = bankname;}
    public String getBankname() {return bankname;}

    public void setBalance(double balance) {this.balance = balance;}
    public double getBalance() {return balance;}


}
