public class Main {
    public static void main(String[] args) {
        PersonAccount personAccount=new PersonAccount("sadsdasda","adsdada",1653.3);
        //chadgmuli clasis gamozdaxeba
        PersonAccount.PlasticCard card=personAccount.new PlasticCard("asdasdwa","454532563","dasdasxe");


        card.printInfo();

        PersonAccount p1=new PersonAccount();
        p1.number(5);
    }
}