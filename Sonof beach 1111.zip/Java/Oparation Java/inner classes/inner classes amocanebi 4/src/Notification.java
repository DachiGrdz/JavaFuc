public abstract class Notification {
    String sender;
    String receiver;
    String text;

    public Notification(String sender, String receiver, String text) {
        this.sender = sender;
        this.receiver = receiver;
        this.text = text;
    }
    abstract void send();
    abstract void receive();

}
