public class Main {
    public static void main(String[] args) {
        Notification mySms = new Notification("nika", "andria ", "java") {
            @Override
            public void send() {
                System.out.println(this.sender + " -> " + this.receiver + " send: " + this.text);
            }

            @Override
            public void receive() {
                System.out.println(this.receiver + " -> " + this.sender + " received " + this.text);
            }
        };


        mySms.send();
        mySms.receive();

    }
}