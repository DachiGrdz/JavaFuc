import java.util.Random;
import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        //        pirveli leqcia ragacis gamotana
        //        System.out.println("I am Back");

//////////////////////////////////////////////////////
//leqcia 2
//        int a=7;
//        int b=15;
//        System.out.println("a==b " + (a==b));
//        System.out.println("a!=b " + (a!=b));
//        System.out.println("a>b " + (a>b));
//        System.out.println("a>=b " + (a>=b));

//        int temperature=30;
//        if(temperature<=30){
//            System.out.println("არ ცხელა");
//        }else{
//            System.out.println("დაცხა");
//        }

///////////////////////////////////////////
//switch operatori
//        int x=30;
//
//        switch (x){
//            case 10:
//                System.out.println("რიცხვის მნიშნელობაა 10");
//                break;
//            case 20:
//                System.out.println("რიცხვის მნიშნელობაა 20");
//                break;
//            case 30:
//                System.out.println("რიცხვის მნიშნელობაა 30");
//                break;
//            case 40:
//                System.out.println("რიცხვის მნიშნელობაა 40");
//                break;
//            case 50:
//                System.out.println("რიცხვის მნიშნელობაა 50");
//                break;
//            case 60:
//                System.out.println("რიცხვის მნიშნელობაა 60");
//                break;
//            case 70:
//                System.out.println("რიცხვის მნიშნელობაა 70");
//                break;
//                //es tu araferi ar dakmayofilda
//            default:
//                System.out.println("ara chemi zdma");
//        }
//        ////////////////
//        // gamartivebuli saxe if operatoris
//        String result="";
//        int x=30;
//        result=(x==30)?"x mnishvnelobaa 30":"x mnishvneloba ar aris 30";
//        System.out.println(result);


//////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//davaleba 2 amoxsnebi
        //#1
        //damatebiti cvladit;
//        int a=10, b=28, c;
//        System.out.println("a ricxvi " + a);
//        System.out.println("b ricxvi " + b);
//        c=a;
//        a=b;
//        b=c;
//        System.out.println("a ricxvi " + a);
//        System.out.println("b ricxvi " + b);
        //damatebiti cvladis gareshe
        //logikuri XOR operatori ^;
//        int a=19, b=27;
//        System.out.println("a ricxvi: "+ a);
//        System.out.println("b ricxvi: "+ b);
//        a= a ^ b;
//        b= b ^ a;
//        a= a ^ b;
//        System.out.println("a ricxvi: "+ a);
//        System.out.println("b ricxvi: "+ b);

        /////////////////////////
//        //#2
//        double i=10.397;
//        System.out.println("i ricxvis aramteli nawili " + i%1);

        /////////////////////////////
        //#3
//        String asoebi="r";
//        switch (asoebi){
//            case "r":
//                asoebi="R";
//                System.out.println(asoebi);
//                break;
//            case "a":
//                asoebi="A";
//                System.out.println(asoebi);
//                break;
//            default:
//                System.out.print("es aso ar arsebobs");
//        }

        /////////////////////////////////
        //#4
//        int a=123;
//        if(a<1000 && a>99){
//            System.out.print("es ricxvi samnishnaa: " + a);
//        }else{
//            System.out.print("es ricxvi araa samnishna: " + a);
//        }
        /////////////////////////////////
        //#5
//        int a=8;
//        int b=0;
//        for (int i=2; i<a; i*=2){
//            b+=i;
//            if(a==b) {
//                System.out.print("Ki");
//            }
//        }
//        if(a!=b){
//            System.out.print("ara");
//        }

        //////////////////////////////////
        //#6
//        double a=13.323;
//        double g=0;
//        g=a-a%1;
//        if(a%1<0.5){
//            System.out.print(g);
//        }else{
//            System.out.print(g+1);
//        }

        //////////////////////////////
        //#7
//        int a=10, b=8, k, f;
//        if (a>b) {
//            for (int i = 0; i<b; i++){
//                k=(b-i)*(b-i);
//                if((a*b)%k==0){
//                    f=(a*b)/k;
//                    System.out.print(k + " zomis kvadratebi eteva    " + f + "-jer");
//                    break;
//                }
//            }
//        }

////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
        //leqcia 3 ciklebi da ganmeorebiti operatorebi
///////////////////////////////////////////////
//////////////////////////////////////////////
//amocanebi 1
        //#1
//        for(int i=10; i<100; i++){
//            if(i%5==0)
//            System.out.print(i + " ");
//        }

        ////////////////////////////
        //#2
//        int a=123, i=10, g=1;
//        while(i<a){
//            i*=10;
//            g++;
//        }
//        System.out.print(g);

        ///////////////////////////
        //#3
//        Scanner scanner = new Scanner(System.in);
//        int a = scanner.nextInt();
//        int g=0;
//        for(int i=2; i<(a/2); i++){
//            if((a%i)==0){
//                g++;
//                System.out.print("ricxvi shedgenilia");
//                break;
//            }
//        }
//        if(g==0){
//            System.out.print("ricxvi martivia");
//        }

        /////////////////////////////////
        //#4
//        int a=250, b=500;
//        while(a>0 && b>0){
//            if(a>b){
//                a=a-b;
//            }else{
//                b=b-a;
//            }
//        }
//        if (a!=0) {
//            System.out.print("udidesi saerto gamyofi: " + a);
//        }else {
//            System.out.print("udidesi saerto gamyofi: " + b);
//        }

        //////////////////////////////////////
        //#5
//        for(int i=101; i<1000; i++){
//            int d = i;
//            int a = d / 100;
//            d %= 100;  // Update i to remove the hundreds digit
//            int b = d / 10;
//            int c = d % 10;  // Extract the units digit
//            if(i%(a+b+c)==0){
//                System.out.print(i + " ");
//            }
//        }
        /////////////////////////////////////////
        //#6
//        int a=0, b=1, c=0;
//        for(int i=0; i<9; i++){
//            c=a+b;
//            a=b;
//            b=c;
//        }
//        System.out.print(c);
//

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//davaleba 3
        //#1
//        for(int i=0; i<40; i++){
//            if(i%2!=0)
//                System.out.println(i);
//        }

        //////////////////////////////
        //#2
//        Scanner scanner = new Scanner(System.in);
//        int a = scanner.nextInt();
//        int g=1;
//        for(int i=1; i<=a; i++){
//            g=g*i;
//        }
//        System.out.print(g);

        //////////////////////////////
        //#3
//        int ng=1, ns=0, n=0;
//        for(int i=1; i<=15; i++){
//            n=n+i;
//            ng=ng*i;
//            ns=n/15;
//        }
//        System.out.println(n);
//        System.out.println(ng);
//        System.out.println(ns);

        /////////////////////////////////
        //#4
//        Scanner scanner=new Scanner(System.in);
//        int a=scanner.nextInt();
//        int b=0;
//        for (int i=1; i<a; i*=2){
//            b+=i;
//            System.out.print(i + " ");
//            if(a==b-1) {
//                System.out.print("Ki");
//            }
//        }
//        if(a!=b-1) {
//            System.out.println("ara");
//        }

        //////////////////////////////
        //#5
//        double y;
//        for(double x=1; x<10; x+=0.5){
//            y=(x*x)+(5*x);
//            System.out.println("F(" + x + ")=X^2+5*x= " + y );
//        }

/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//leqcia 4 masivebi da masze mushaoba
//
//        int arr[]= new int[5];
//        int arr2[]={1,2,3,4,5};

        //////////////////////////////////
//        int arr[]=new int[10];//ertganzomilebiani masivis sheqmna
//
//        for(int index=0; index<10; index++){
//            arr[index]=index;//inicializacia
//        }
//
//        for(int i=0; i<10; i++){
//            System.out.println("arr["+i+"]="+arr[i]);
//        }

        ///////////////////////////////////////
//        int arr[]=new int[10];
//
//        for(int index=0; index<10; index++){
//            arr[index]=index;
//        }
//
//        for(int a:arr){
//            System.out.println(a);
//        }

        ///////////////////////////////////////////
        //organzomilebiani masivebi
//        int arr[][]={{1,2,3},{1,2,3},{1,2,3}};
//
//        int arr2[][]=new int[5][5];
//
//        //chadgmuli ciklebit inicializacia organzomilebiani masivebis
//        for(int i=0; i<5; i++){
//            for(int j=0; j<5; j++){
//                arr2[i][j]=(i+j);
//                System.out.print(arr2[i][j]+" ");
//            }
//            System.out.println(" ");
//        }

        /////////////////////////////////////////////
        //შემთხვევითი რიცხვების გენერაცია
//        Random r= new Random();
//        int arr[]=new int[10];
//
//        for(int i=0; i<10; i++){
//            arr[i]=r.nextInt(10);
//        }
//
//        for (int i=0; i<10; i++){
//            System.out.print(arr[i]+" ");
//        }

        ///////////////////////////////////////////
        //klasshi garcheuli amocanei masivebze
//        Scanner scanner=new Scanner(System.in);
//        int a[]=new int[5];
//
//        for(int i=0; i<a.length; i++){
//            a[i]=scanner.nextInt();
//        }
//
//        for(int i=0; i<a.length; i++){
//            System.out.print(a[i]+" ");
//        }
//
//        System.out.println(":");
//        System.out.println("---------------------------");
//
//        for (int x:a){
//            System.out.print(x+" ");
//        }

        ////////////////////////////////////////////
        //#2 array2
//        Scanner scanner=new Scanner(System.in);
//        int b[][]=new int[5][3];
//
//        for(int i=0; i<5; i++){
//            for (int j=0; j<3; j++){
//                b[i][j]=scanner.nextInt();
//            }
//        }
//
//        for(int i=0; i<5; i++){
//            for (int j=0; j<3; j++){
//                System.out.print(b[i][j]+" ");
//            }
//            System.out.println(" ");
//        }

        ///////////////////////////////////////////
        //#3 array3
//        Random random=new Random();
//        int arr[][]=new int[5][7];
//
//        for(int i=0; i<5; i++){
//            for(int j=0; j<7; j++){
//                arr[i][j]=random.nextInt(10);
//            }
//        }
//
//        for (int i=0; i<5; i++){
//            for (int j=0; j<7; j++){
//                System.out.print(arr[i][j]+" ");
//            }
//            System.out.println(" ");
//        }

        //////////////////////////////////////////////
        //#4 array4
//
//        Random random=new Random();
//        int arr[]=new int[26];
//
//        for(int i=0; i<arr.length; i++){
//            arr[i]=random.nextInt(20);
//        }
//
//        for(int i=0; i<arr.length; i++){
//            System.out.print(arr[i]+" ");
//        }
//
//        int max=arr[0];
//        int min=arr[0];
//
//        for(int i=0; i<arr.length; i++){
//            if(max<arr[i]){
//                max=arr[i];
//            }
//            if (min>arr[i]){
//                min=arr[i];
//            }
//        }
//        System.out.println(" ");
//
//        System.out.println("masivshi maqsimaluri elementi: "+max);
//        System.out.println("masivshi minimaluri elementi: "+min);

/////////////////////////////////////////////////////////////
        //დავალება 4
        //#1 da #2
//        Random random=new Random();
//        int b[]=new int[12];
//        int jumi=0, sash;
//        long namr=1;
//
//        for(int i=0; i<b.length; i++){
//            b[i]=random.nextInt(5);
//            System.out.print(b[i]+" ");
//            jumi+=b[i];
//            namr*=b[i];
//        }
//        sash=jumi/b.length;
//        System.out.println(" ");
//        System.out.println("მასივის წევრების ჯამი: "+jumi);
//        System.out.println("მასივის წევრების ნამრავლი: "+namr);
//        System.out.println("მასივის წევრების საშუალო არითმეტიკული: "+sash);

        ///////////////////////////////////////////////
        //#4
//        Random random=new Random();
//        int arr[][]=new int[9][9];
//        long namravli=1;
//
//        for(int i=0; i<9; i++){
//            for (int j=0; j<9; j++){
//                arr[i][j]=random.nextInt(25);
//                System.out.print(arr[i][j]+" ");
//            }
//            namravli*=arr[i][i];
//            System.out.println(" ");
//        }
//        System.out.println("namravli: "+namravli);

        ///////////////////////////////////////////////////
        //#5
//        Random random=new Random();
//        int arr[][]=new int[7][7];
//        int luw=0, ken=0;
//
//        for(int i=0; i<7; i++){
//            for(int j=0; j<7; j++){
//                arr[i][j]= random.nextInt(30);
//                if(arr[i][j]%2==0){
//                    luw++;
//                }else {
//                    ken++;
//                }
//            }
//        }
//        if(luw>ken){
//            System.out.println("luwebis raodenoba metia da udris: "+luw);
//        }else{
//            System.out.println("kentebis raodenoba metia da udris: "+ken);
//        }

        ////////////////////////////////////////////////////
        //#6 da #7
//        Scanner scanner=new Scanner(System.in);
//        int arr[]=new int[15];
//        int jumi=0, namr=1;
//        int x=scanner.nextInt();
//
//        for(int i=0; i<arr.length; i++){
//            arr[i]=i+1;
//            System.out.print(arr[i]+" ");
//            jumi+=arr[i];
//            namr*=arr[i];
//            if(arr[i]==x){
//                System.out.println(" ");
//                System.out.println("X ricxvi aris masivshi: ");
//            }
//        }
//        System.out.println(" ");
//        System.out.println("jumi: "+jumi);
//        System.out.println("namravli: "+namr);

////////////////////////////////////////////////////////
        /////////////////////////////////////////////////
        /////////////////////////////////////////////////
        ///////////////////////////////////////////////////
        //practikuli amocanebi klasshi
        //#1
//        Scanner scanner=new Scanner(System.in);
//
//        int n=scanner.nextInt();
//        if(n%7==0){
//            System.out.println("მოცემული რიცხვი იყოფა 7-ზე: "+n);
//        }else {
//            System.out.println("მოცემული რიცხვი არ იყოფა: "+n);
//        }

        /////////////////////////////////////////////////
        //#2
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("შეიყვანეთ X ცვლადი: ");
//        int x=scanner.nextInt();
//
//        System.out.println("შეიყვანეთ Y ცვლადი: ");
//        int y=scanner.nextInt();
//
//        System.out.println("შეიყვანეთ Z ცვლადი: ");
//        int z=scanner.nextInt();
//        int f=x+y;
//        f=f^2; f*=2; f=f-(z^3); f+=18;
//
//        System.out.println("მოცწმული ფორმულა 2((x+y)^2)-(z^3)+18: "+f);

        ////////////////////////////////////////////////////
        //#3
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("რამდენი კილოვატი დაიწვა: ");
//        int deni=scanner.nextInt();
//        System.out.println("რამდენი კუბურუ მეტრი გაზი დაიწვა: ");
//        int gazi=scanner.nextInt();
//        System.out.println("რამდენი სული მოსახლეა ბინაში: ");
//        int ramdeniK=scanner.nextInt();
//
//        System.out.println("დასუფთავების გადასახადია: "+ramdeniK*4+" ლარი");
//        System.out.println("წყლის გადასახადია: "+ramdeniK*3+"ლარი");
//        System.out.println("დენის გადასახადი: "+deni*0.18+" ლარი");
//        System.out.println("გაზის გადასახადი: "+gazi*0.2+" ლარი");
//        System.out.println("ჯამში გადასახდელია: "+(ramdeniK*4+ramdeniK*3+deni*0.18+gazi*0.2)+" ლარი");

        /////////////////////////////
        //#4
//        Scanner scanner=new Scanner(System.in);
//        int n=scanner.nextInt();
//
//        System.out.print(" საათი: "+n/3600);
//        n=n%3600;
//        System.out.print(" წუთი: "+n/60);
//        n=n%60;
//        System.out.print(" წამი: "+n);

        ////////////////////////////////////////////
        //#5
//        int a,b,c;
//        int d,e,f;
//        Scanner input = new  Scanner(System.in);
//        a=input.nextInt();
//        b=input.nextInt();
//        c=input.nextInt();
//        System.out.println("-------------------------");
//        d=input.nextInt();
//        e=input.nextInt();
//        f=input.nextInt();
//        int amosvla=a*3600+b*60+c;
//        int chasvla=d*3600+e*60+f;
//        System.out.println("მზე ამოსული იყო" + (chasvla-amosvla)+"წამი");

        /////////////////////////////////////////////////
        //#6
//        Scanner scanner=new Scanner(System.in);
//        int m=scanner.nextInt();
//
//        switch (m){
//            case 1:
//            case 2:
//            case 12:{
//                System.out.println("ზამთარი");
//            break;
//            }
//            case 3:
//            case 4:
//            case 5:{
//                System.out.println("გაზაფხული");
//            break;
//            }
//            case 6:
//            case 7:
//            case 8:{
//                System.out.println("ზაფხული");
//            break;
//            }
//            case 9:
//            case 10:
//            case 11:{
//                System.out.println("შემოდგომა");
//            break;
//            }
//            default:
//                System.out.println("თვე შეგეშალა");
//                break;
//        }

        /////////////////////////////////////////
        //#7
//        Scanner scanner=new Scanner(System.in);
//
//        int x=scanner.nextInt();
//
//        if(2<x && x<5){
//            System.out.println("Yes");
//        }
//        if(11<x && x<24){
//            System.out.println("Yes");
//        }else{
//            System.out.println("No");
//        }

        ////////////////////////////////////////
        //#8
//        Scanner scanner=new Scanner(System.in);
//
//        System.out.println("ჩაწერე სამნიშნა რიცხვი: ");
//        int n=scanner.nextInt();
//
//        if(n%100*(n/100)<n%10*(n/10)){
//            System.out.println("უდიდესი რიცხვის მნიშვნელობა: "+n%10*(n/10));
//        }else{
//            System.out.println("უდიდესი რიცხვის მნიშვნელობა: "+n%100*(n/100));
//        }

        ////////////////////////////////////////
        //#9
//        Scanner scanner = new Scanner(System.in);
//
//        char grade = scanner.next().charAt(0);
//
//        switch (grade) {
//
//            case 'A':
//                System.out.println("[91-100]");
//                break;
//            case 'B':
//                System.out.println("[81-90]");
//                break;
//            case 'C':
//                System.out.println("71-80");
//                break;
//            case 'D':
//                System.out.println("61-70");
//                break;
//            case 'E':
//                System.out.println("51-60");
//                break;
//            default:
//                System.out.println("არ არსებული შეფასება");


        /////////////////////////////////////////////
        //#10
//        int sum=0;
//        for(int i=310; i<452; i++){
//            if(i%7==0){
//                sum+=i;
//            }
//        }
//        System.out.println(sum);

        ////////////////////////////////////////////
        //#11
//        Scanner scanner=new Scanner(System.in);
//        int x=scanner.nextInt();
//        boolean j=false;
//        for(int i=2; i<x/2; i++){
//            if(x%i==0){
//                System.out.println("შედგენილია:");
//                j=false;
//                break;
//            }else {
//                j=true;
//            }
//        }
//        if(j){
//            System.out.println("მარტივია: ");
//        }

        /////////////////////////////////////
        //#12
//        for(int i=1; i<=9999; i++){
//            if(i/1000+(i/100)%10==i%10+(i%100)/10){
//                System.out.println("Lucky Number: "+i);
//            }
//        }

        /////////////////////////////////////////////
        //#13
//        int a=0, b=1, c=0;
//        for(int i=0; i<=10; i++){
//            c=a+b;
//            a=b;
//            b=c;
//            System.out.println(a);
//        }

        ///////////////////////////////////////////////
        //#14
//        int a=225, b=125;
//        int c=a, d=b;
//        while(a>0 && b>0){
//            if(a>b){
//                a=a-b;
//            }else{
//                b=b-a;
//            }
//        }
//        if (a!=0) {
//            System.out.println("udidesi saerto gamyofi: " + a);
//            System.out.println("umciresi saerto jeradi: " + c*d/a);
//        }else {
//            System.out.print("udidesi saerto gamyofi: " + b);
//        }

        ///////////////////////////////////////////////////////
        //#15
//        Random random=new Random();
//
//        int arr[]=new int[10];
//
//        for(int i=0;i<10; i++){
//            arr[i]=random.nextInt(20);
//            System.out.println(arr[i]+" ");
//        }
//
//        for ()
/////////////////////////////gamovtove radgan mezareboda dasrulebaa
//
        ////////////////////////////////////////////////
        //#16
//        Random random=new Random();
//
//        int arr1[]=new int[10];
//        int arr2[]=new int[10];
//
//        for(int i=0; i<10; i++){
//            arr1[i]= random.nextInt(20);
//            arr2[i]= random.nextInt(20);
//            System.out.println(arr1[i]+"    "+arr2[i]);
//        }
//        for(int i=0; i<10; i++){
//            for (int j=0; j<10; j++){
//                if(arr1[i]==arr2[j]){
//                    System.out.println(arr1[i]+" ");
//                    break;
//                }
//            }
//        }

        ////////////////////////////////////////////////
        //#17
//        Random random=new Random();
//        int arr[][]=new int[4][4];
//
//        for(int i=0; i<4; i++){
//            for (int j=0; j<4; j++){
//                arr[i][j]=random.nextInt(30);
//                System.out.print(arr[i][j]+" ");
//            }
//            System.out.println(" ");
//        }
//        int mx=arr[0][0];
//        for(int i=0; i<4; i++){
//            for (int j=0; j<4; j++){
//                if(mx<arr[i][j]){
//                    mx=arr[i][j];
//                }
//            }
//        }
//        System.out.println("maximaluri elementi: "+mx);

        ////////////////////////////////////////////////////
        //#18
//        Random random=new Random();
//        int arr1[][]=new int[4][4];
//        int arr2[][]=new int[4][4];
//        for(int i=0; i<4; i++){
//            for (int j=0; j<4; j++){
//                arr1[i][j]=random.nextInt(30);
//                arr2[i][j]=random.nextInt(30);
//            }
//        }
//        int arr3[][]=new int[4][4];
//        for(int i=0; i<4; i++){
//            for (int j=0; j<4; j++){
//                arr3[i][j]=arr1[i][j]+arr2[i][j];
//                System.out.print(arr3[i][j]+" ");
//            }
//            System.out.println(" ");
//        }

        /////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////
        //////////////////////////////////////////////////////
        //////////////////////////////////////////////////////
        //sakontrolo wera 1
        //#1   g) d)
        //#2   d)
        //#3   g)
        //#4   b)
        //#5   a)

        ////////////////////////////////////////////
        //#6
//        Random random=new Random();
//        int arr[][]=new int[10][10];
//        int k=0,h=0, mx=0;
//        for(int i=0; i<10; i++){
//            for (int j=0; j<10; j++){
//                arr[i][j]=random.nextInt(100);
//                if(mx<arr[i][j]){
//                    k=i;
//                    h=j;
//                    mx=arr[i][j];
//                }
//            }
//        }
//        System.out.println("Indexsebi "+k+" "+h+" maxsimaluri ricxvi udris: "+mx);

        //////////////////////////////////////////
        //#7
//        Random random=new Random();
//        int arr1[][]=new int[5][5];
//        int arr2[][]=new int[5][5];
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                arr1[i][j]=random.nextInt(100);
//                arr2[i][j]=random.nextInt(100);
//            }
//        }
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                System.out.print(arr1[i][j]+" ");
//            }
//            System.out.println(" ");
//        }
//        System.out.println("------------------------------------");
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                System.out.print(arr2[i][j]+" ");
//            }
//            System.out.println(" ");
//        }
//        System.out.println("--------------------------------");
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                for(int k=0; k<5; k++){
//                    for (int h=0; h<5; h++){
//                        if(arr1[i][j]==arr2[k][k]){
//                            System.out.print(arr1[k][h]+" ");
//                        }
//                    }
//                }
//            }
//        }

        ////////////////////////////////////////////
        //#8
//        int n;
//        int cnt = 0;
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.println("შემოიტანეთ რიცხვი:");
//        n = scanner.nextInt();
//
//        while (n % 10 == 0) {
//            n = n / 10;
//        }
//
//        while(n>0){
//            cnt++;
//            n=n/10;
//        }
//        System.out.println(cnt);

        //////////////////////////////////////////////
        //#9
//        Random random=new Random();
//        int arr1[][]=new int[5][5];
//        int arr2[][]=new int[5][5];
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                arr1[i][j]=random.nextInt(100);
//                arr2[i][j]=random.nextInt(100);
//            }
//        }
//        int arr3[][]=new int[5][5];
//
//        for(int i=0; i<5; i++){
//            for (int j=0; j<5; j++){
//                arr3[i][j]=arr2[i][j]+arr1[i][j];
//                System.out.print(arr3[i][j]+" ");
//            }
//            System.out.println(" ");
//        }

        ////////////////////////////////////////
        //#10
//        double d = 1.125;
//        int mricxveli;
//        int mnishvneli = 1000;
//        mricxveli = (int) (d * 1000);
//        int usg = 1;
//
//        for (int i = 1000; i >= 1; i--) {
//            if (mnishvneli % i == 0 && mricxveli % i == 0) {
//                usg = i;
//                break;
//            }
//        }
//        System.out.println(mricxveli / usg);
//        System.out.println("------------");
//        System.out.println(mnishvneli / usg);

    }
}




















