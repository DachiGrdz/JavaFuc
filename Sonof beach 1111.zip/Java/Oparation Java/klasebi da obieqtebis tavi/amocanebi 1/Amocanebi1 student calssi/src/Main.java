public class Main {
    public static void main(String[] args) {
        Student s1=new Student();
        s1.fname="Dachi";
        s1.lname="Grdzelishvili";
        s1.age=19;
        s1.gpa=3.61;

        System.out.println("First Name: "+s1.fname);
        System.out.println("Last Name: "+s1.lname);
        System.out.println("Age: "+s1.age);
        System.out.println("GPA: "+s1.gpa);

        s1.stadying();
        s1.score();

    }
}