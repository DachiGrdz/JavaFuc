public class Student {
    String fname;
    String lname;
    int age;
    double gpa;

    void stadying(){
        System.out.println(fname+" "+lname+" is stadying");
    }

    void score(){
        int intValue = (int) gpa;
        System.out.println("Score "+intValue);
    }

}
