//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static   void main(String[] args) {
        Car c1=new Car();
        c1.marka="Ural";
        c1.modeli="300";
        c1.gweli=1984;
        c1.saxen="BA-125-LI";

        Car c2=new Car();
        c2.marka="Opel";
        c2.modeli="Astra";
        c2.gweli=1991;
        c2.saxen="HH-369-GG";

        c1.printInfo();
        c2.printInfo();
    }
}