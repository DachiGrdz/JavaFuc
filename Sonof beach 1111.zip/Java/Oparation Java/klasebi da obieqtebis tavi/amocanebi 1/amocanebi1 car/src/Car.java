public class Car {
    String marka;
    String modeli;
    int gweli;
    String saxen;
    void printInfo(){
        System.out.println("ავტომობილის ინფორმაცია ");
        System.out.println("მარკა: "+marka);
        System.out.println("მოდელი: "+modeli);
        System.out.println("წლოვანება: "+gweli);
        System.out.println("სახელმწიფო ნომერი: "+saxen);
        System.out.println("------------------");

    }
}
