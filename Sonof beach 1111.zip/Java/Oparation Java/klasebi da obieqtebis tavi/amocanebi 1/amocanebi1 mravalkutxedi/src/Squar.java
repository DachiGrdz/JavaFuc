public class Squar {
    double sizel;
    double sizes;

    void num(){
        System.out.println("Fartobi: "+sizel*sizes);
    }

    void peri(){
        System.out.println("Perimetri: "+2*(sizes+sizel));
    }

}
