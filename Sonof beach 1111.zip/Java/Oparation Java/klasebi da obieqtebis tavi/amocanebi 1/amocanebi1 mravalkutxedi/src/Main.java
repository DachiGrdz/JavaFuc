//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Squar ob1=new Squar();
        ob1.sizel=10.5;
        ob1.sizes=30.25;

        Squar ob2=new Squar();
        ob2.sizes=11.2;
        ob2.sizel=12.3;

        System.out.println("სიგრძე: "+ob1.sizel);
        System.out.println("სიგანე: "+ob1.sizes);
        ob1.num();
        ob1.peri();

        System.out.println("---------------------");
        System.out.println("სიგრძე: "+ob2.sizel);
        System.out.println("სიგანე: "+ob2.sizes);
        ob2.num();
        ob2.peri();
    }
}