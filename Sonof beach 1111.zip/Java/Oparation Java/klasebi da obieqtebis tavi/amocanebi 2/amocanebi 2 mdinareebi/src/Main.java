import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random=new Random();
        River[] rivers=new River[3];

        rivers[0] = new River();
        rivers[0].name="yvirila";
        rivers[0].lenght=random.nextInt(10,30);

        rivers[1] = new River();
        rivers[1].name="dumala";
        rivers[1].lenght=random.nextInt(10,30);

        rivers[2] = new River();
        rivers[2].name="zdirula";
        rivers[2].lenght=random.nextInt(10,30);

        int m=0, n=0;
        for(int i=1; i<3; i++){
            int max=rivers[0].lenght;
            int min=rivers[0].lenght;
            if(max<rivers[i].lenght){
                max=rivers[i].lenght;
                m=i;
            }
            if (min>rivers[i].lenght){
                min=rivers[i].lenght;
                n=i;
            }
        }
        rivers[m].mx();
        System.out.println("----------------------");
        rivers[n].mn();
    }
}