public class River {
    String name;
    int lenght;

    void mx(){
        System.out.println("მდინარის სახელი: "+name+" სიგრძე: "+lenght);
    }
    void mn(){
        System.out.println("მდინარის სახელი: "+name+" სიგრძე: "+lenght);
    }
}
