public class Lake {
    String name;
    int fartobi;
    int sirgme;

    void mx(){
        System.out.println("მაქსიმალური სირღმის ტბის სახელი: "+name);
    }
}
