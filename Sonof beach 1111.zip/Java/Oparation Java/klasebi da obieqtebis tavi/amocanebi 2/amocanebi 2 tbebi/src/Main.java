import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random=new Random();
        Lake[] lakes=new Lake[3];

        lakes[0] = new Lake();
        lakes[0].name="lisi";
        lakes[0].fartobi=random.nextInt(100,150);
        lakes[0].sirgme=random.nextInt(100,150);

        lakes[1] = new Lake();
        lakes[1].name="tabawyuri";
        lakes[1].fartobi=random.nextInt(100,150);
        lakes[1].sirgme=random.nextInt(100,150);

        lakes[2] = new Lake();
        lakes[2].name="sevani";
        lakes[2].fartobi=random.nextInt(100,150);
        lakes[2].sirgme=random.nextInt(100,150);

        int m=0;
        for(int i=1; i<3; i++){
            int max=lakes[0].sirgme;
            int min=lakes[0].sirgme;
            if(max<lakes[i].sirgme){
                max=lakes[i].sirgme;
                m=i;
            }
        }
        lakes[m].mx();
    }
}