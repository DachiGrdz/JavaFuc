public class Main {
    public static void main(String[] args) {
        wrewiri w1=new wrewiri(3.6);

        w1.sigrdze();
        System.out.println("---------------");
        w1.fartobi();
    }
}