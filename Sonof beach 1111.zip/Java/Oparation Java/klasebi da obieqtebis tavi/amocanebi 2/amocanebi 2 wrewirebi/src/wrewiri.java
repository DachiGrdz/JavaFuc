public class wrewiri {
    double radiusi;

    public wrewiri(double r){
        radiusi=r;
    }

    void sigrdze(){
        System.out.println("წრეწირის სიგრძე "+radiusi*2*3.14);
    }

    void fartobi(){
        System.out.println("წრეწირის ფართობი "+radiusi*radiusi*3.14);
    }
}
