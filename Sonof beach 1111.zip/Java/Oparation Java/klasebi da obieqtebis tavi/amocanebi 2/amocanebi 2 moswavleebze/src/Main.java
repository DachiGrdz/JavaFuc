import java.util.Random;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Student[] students=new Student[3];

        students[0] = new Student();
        students[0].fname="lizi";
        students[0].lname="gaxaria";
        students[0].height=1.55;
        students[0].s=true;

        students[1] = new Student();
        students[1].fname="dachi";
        students[1].lname="grdzelishvili";
        students[1].height=1.55;
        students[1].s=false;

        students[2] = new Student();
        students[2].fname="mariam";
        students[2].lname="bagrationi";
        students[2].height=1.55;
        students[2].s=true;

        int c=0;
        for(int i=0; i<3; i++){
            if (students[i].s){
                c++;
            }
        }
        System.out.println("გოგო მოსწავლეების რაოდენობა: "+c);
    }
}