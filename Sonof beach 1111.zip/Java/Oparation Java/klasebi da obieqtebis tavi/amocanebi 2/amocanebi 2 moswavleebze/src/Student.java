public class Student {
    String fname;
    String lname;
    double height;
    boolean s;
}
