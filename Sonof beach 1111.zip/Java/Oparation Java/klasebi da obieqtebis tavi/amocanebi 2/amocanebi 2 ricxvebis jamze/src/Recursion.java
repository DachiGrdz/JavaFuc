public class Recursion {
    int fact(int n){
        if(n==0) return 0;
        return n+fact(n-1);
    }

    int num(int n){
        return n*n*n;
    }
}
