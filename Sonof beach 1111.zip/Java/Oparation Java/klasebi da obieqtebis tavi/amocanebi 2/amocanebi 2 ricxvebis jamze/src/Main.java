public class Main {
    public static void main(String[] args) {
        Recursion r=new Recursion();

        //////////////////////////
        //#6
        int f=r.fact(10);
        System.out.println(f);

        //////////////////////////
        //#7

        int s=r.num(5);
        System.out.println(s);
    }
}