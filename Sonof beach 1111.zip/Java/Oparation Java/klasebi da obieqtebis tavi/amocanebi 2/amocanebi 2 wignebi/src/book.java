public class book {
    String name;
    String author;
    int age;

    public book(String n, String a, int ag){
        name=n;
        author=a;
        age=ag;
    }

    void Printinfo(){
        System.out.println("წიგნის სახელი: "+name+" ავტორი: "+author+" გამოშვების წელი"+age);
    }
}
