public class Main {
    public static void main(String[] args) {
        book b1=new book("300 aragveli","erekle 2",1795);
        b1.Printinfo();
    }
}