public class Recursion {

    ////////////////////////////////////////
    //#1
//    static double Recur(int current, int n) {
//        if (current == 0) return 0;
//
//        else {
//            double term = Math.pow(current, 2) / Math.pow(n, 2);
//            return term + Recur(current - 1, n);
//        }
//    }

    ////////////////////////////////////////////
    //#2
    /////////////////////////////////////////////
    //tvini gaburga
    int fact(int n){
        if(n==1) return 1;
        else{
            int c=0;
            if(n%10==0){
                fact(n%10);
                return c++;
            }else{
                fact(n/10);
            }
        }

    }

}
