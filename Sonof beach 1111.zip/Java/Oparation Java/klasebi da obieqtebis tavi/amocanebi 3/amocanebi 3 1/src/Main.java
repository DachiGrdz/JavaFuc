import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ////////////////////////////////
        //#1
//        Scanner scanner=new Scanner(System.in);
//        int n=scanner.nextInt();
//
//        Recursion r=new Recursion();
//
//        double result = r.Recur(n, n);
//        System.out.println("Result: " + result);


        ///////////////////////////////////
        //#2
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        Recursion r=new Recursion();

        int ra=r.fact(n);
        System.out.println(ra);
    }
}