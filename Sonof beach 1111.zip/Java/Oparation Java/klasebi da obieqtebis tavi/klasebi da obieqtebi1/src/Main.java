public class Main {
    public static void main(String[] args) {
        Person p = new Person(); //Person კლასის ობიექტის შექმნა
                                 //უპარამეტრო კონსტრუქტორით

        p.firstname="Dachovani";
        p.lastname="Grdzelishvili";
        p.age=20;
        p.idnum="014525154";

        System.out.println("First Name: "+p.firstname);
        System.out.println("Last Name: "+p.lastname);
        System.out.println("IdNum: "+p.idnum);
        System.out.println("Age: "+p.age);

        p.speak();
        p.walk();
        System.out.println("--------------------------");

        //Person კლასის ობიექტების შექმნა პარამეტრიზირებული კონსტრუქტორით

        Person p2=new Person("დაჩოვანა","გრძელი","04151356",19);

        System.out.println("First Name: "+p2.firstname);
        System.out.println("Last Name: "+p2.lastname);
        System.out.println("IdNum: "+p2.idnum);
        System.out.println("Age: "+p2.age);

        p2.speak();//speak metodis gamozdaxeba
        p2.walk();//walk metodis gamozaxeba

    }
}