public class Person {
    String firstname;
    String lastname;
    String idnum;
    int age;

    public Person(){}//უპარამეტრო კონსტრუქტორი

    public Person(String fname, String lname, String id, int a){
        this.firstname=fname;
        this.lastname=lname;
        this.idnum=id;
        this.age=a;
    }//პარამეტრიანი კონსტრუქტორი

    void speak(){
        System.out.println(firstname+" "+lastname+" is speaking");
    }
    void walk(){
        System.out.println(firstname+" "+lastname+" is walking");
    }


}
