//PARAMETRIANI METODI
//public class Numbers {
//    int sum(int a, int b){
//        return a+b;
//    }
//
//    int max(int a, int b){
//        if(a>b) return a;
//        return b;
//    }
//}

///////////////////////////////
//rekursiuli funqcia
public  class Numbers {
    long fact(long n){
        if(n==1) return 1;
        return n*fact(n-1);
    }
}