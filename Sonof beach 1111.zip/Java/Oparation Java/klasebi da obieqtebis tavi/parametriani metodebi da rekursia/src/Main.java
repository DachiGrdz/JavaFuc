public class Main{
    public static void main(String[] args){
        //PARAMETIRANI METODEBI
        //Numbers n= new Numbers();
//
//        System.out.println(n.max(10,36));
//        System.out.println(n.sum(26,85));

        /////////////////////////////
        //rekursiuli funqcia
        Numbers n=new Numbers();

        long f=n.fact(6);
        System.out.println(f);

    }
}