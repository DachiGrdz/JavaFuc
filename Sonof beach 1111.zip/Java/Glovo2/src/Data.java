//import java.io.*;
//
//public class Data {
//
//    private static final String filaPath = "D:\\Contacts.txt";
//
//    public static void saveData(PhoneCotact[] arr) {
//
//        try {
//            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(filaPath));
//            objectOutputStream.writeObject(arr);
//            objectOutputStream.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    public static PhoneCotact[] getData() {
//        PhoneCotact[] arr = null;
//        try {
//            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(filaPath));
//            arr = (PhoneCotact[]) objectInputStream.readObject();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//        return arr;
//    }
//}
