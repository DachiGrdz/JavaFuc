//import java.util.Scanner;
//import java.util.stream.IntStream;
//
//public class Main {
//
//}
////
////    public static void main(String[] args) {
////        Runnable [] runnables = { new M1(), new M2() };
////        IntStream.range(0, runnables.length)
////                .forEach(i -> System.out.println(i + " " + runnables[i].getClass().getSimpleName()));
////        Scanner scanner = new Scanner(System.in);
////        int choice = scanner.nextInt();
////        if (choice >=0 && choice < runnables.length) {
////            System.out.println("Your choice: " + runnables[choice].getClass().getSimpleName());
////            runnables[choice].run();
////        }
////    }
////
////    public static class M1 implements Runnable {
////        @Override
////        public void run() {
////            System.out.println("I choose to run M1");
////        }
////    }
////
////    public static class M2 implements Runnable {
////        @Override
////        public void run() {
////            System.out.println("M2 was chosen this time...");
////        }
////    }
////}
import java.util.Scanner;
public class Main {

    public static void main(String [] args){

        Scanner in = new Scanner(System.in);
        System.out.println("1\t შემოიხედე გენაცვალე");
        System.out.println("2\t მამაპაპური");
        System.out.println("3\t ვენდისი");
        System.out.println("4\t ლუდის სახლი");
        System.out.println("აირჩიე რესტორანი:");

        int choice=in.nextInt();

        switch (choice) {
            case 1: System.out.println("რესტორანი: შემოიხედე გენაცვალე ");
                break;
            case 2: System.out.println("რესტორანი: მამაპაპური");
                break;
            case 3: System.out.println("რესტორანი: ვენდისი");
                break;
            case 4: System.out.println("რესტორანი: ლუდის სახლი");
                break;
            default: System.out.println("Invalid choice");
        }
        if (choice==1){
            System.out.println("1\t ხინკალი 0.60");
            System.out.println("2\t პელმენი 0.20");
            System.out.println("3\t ხაწაპური 3.00");
            System.out.println("4\t ღვინო 12.00");
            System.out.println("საჭმელი:");

        }
        int choice1=in.nextInt();
        switch (choice1) {
            case 1: System.out.println("ხინკალი");
                break;
            case 2: System.out.println("პელმენი");
                break;
            case 3: System.out.println("ხაწაპური");
                break;
            case 4: System.out.println("ღვინო");
                break;
            default: System.out.println("Invalid choice");
        }

        if (choice==2){
            System.out.println("1\t ხინკალი 0.60");
            System.out.println("2\t ჩურჩხელა 2.20");
            System.out.println("3\t ხაწაპური 3.00");
            System.out.println("4\t ღვინო 12.00");
            System.out.println("საჭმელი:");
        }


    }
}






//import java.util.Scanner;
//
//public class Main {
//
//
//    private static PhoneCotact[] phoneContactsArr = new PhoneCotact[30];
//    private static String name;
//    private static String lastName;
//    private static String phoneNumber;
//    private static String email;
//    private static Scanner scanner = new Scanner(System.in);
//
//    private static int userChoice() {
//
//        System.out.println("1-დამატება");
//        System.out.println("2-რედაქტირება");
//        System.out.println("3-წაშლა");
//        System.out.println("4-კონტაქტების ნახვა");
//        System.out.println("0 - პროგრამიდან გამოსვლა");
//
//        int choice = scanner.nextInt();
//        return choice;
//    }
//
//    private static void addContact() {
//
//        System.out.println("შემოიტანეთ სახელი");
//        name = scanner.next();
//        System.out.println("შემოიტანეთ გვარი");
//        lastName = scanner.next();
//        System.out.println("შემოიტანეთ ტელეფონის ნომერი");
//        phoneNumber = scanner.next();
//        System.out.println("შემოიტანეთ იმეილი");
//        email = scanner.next();
//
//        PhoneCotact phoneCotact = new PhoneCotact();
//        phoneCotact.setName(name);
//        phoneCotact.setLastName(lastName);
//        phoneCotact.setEmail(email);
//        phoneCotact.setPhoneNumber(phoneNumber);
//
//    }
//
//    public static void main(String[] args) {
//
//    }
//}
