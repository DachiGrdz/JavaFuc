import com.sun.xml.internal.ws.api.addressing.OneWayFeature;

import javax.jws.soap.SOAPBinding;
import java.io.*;
import java.util.ArrayList;

public class FileInPutOutPut {
    public final String UserFile = "D:\\AppUser.txt";
    public void saveUser(ArrayList<User> usersArrayList){
        try{
            FileOutputStream fileOutputStream = new FileOutputStream(UserFile);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(FileOutputStream);
            objectOutputStream.writeObject(usersArrayList);
            objectOutputStream.close();
            fileOutputStream.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public ArrayList<User> getUser(){
        ArrayList<User> User = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(User);
            ObjectInputStream objectInputStream = new ObjectInputStream(FileInputStream);
            User =(ArrayList<User>) objectInputStream.readObject();
            objectInputStream.close();
            FileInputStream.close();
        }catch (FileNotFoundException e){
            System.out.println("ფაილი ვერ მოიძებნა");
        }catch (IOException e){
            e.printStackTrace();
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        return User;
    }
}
