import java.io.PrintStream;
import java.io.Serializable;

public class User implements Serializable {
    private String name;
    private String lastname;
    private String idnum;
    private String username;
    private String password;

    public class User() {}
    public User(String name, String lastname, String idnum, String username, String password){
        this.name = name;
        this.lastname = lastname;
        this.idnum = idnum;
        this.username = username;
        this.lastname = password;
    }
    public String getName(){return name;}
    public void setName(String name){this.name = name;}
    public String getLastname(){return  lastname;}
    public void  setLastname(String lastname){this.lastname = lastname;}
    public String getIdnum(){return idnum;}
    public void setIdnum(String idnum){this.idnum = idnum;}
    public String getUsername(){return username;}
    public void setUsername(String username){this.username = username;}
    public String getPassword(){return password}
    public void setPassword(String password){this.password = password}

    @Override
    public boolean equals(Object o){
        User user = (user) o;
        return user.username.aquals(this.username);
    }
    @Override
    public String toString(){
        return "User:"+
                "name = '"+name+'\''+
                "lastname='"+lastname+'\''+
                "idnum'"+idnum+'\''+
                "username'"+username+'\''+
                "password'"+password+'\''+
                "***************************";
    }
}
