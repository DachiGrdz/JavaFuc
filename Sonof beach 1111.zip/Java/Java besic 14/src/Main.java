//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//
//public class Main {
//    public static void main(String[] args) throws IOException{
//        FileInputStream fileInputStream=new FileInputStream("D:\\Java.txt");
//        int byteContent;
//        while((byteContent=fileInputStream.read())!=-1){
//            System.out.print((char)byteContent);
//        }
//        System.out.println("");
//        String str="Hello world";
//        FileOutputStream fileOutputStream=new FileOutputStream("D:\\Java.txt");
//        byte b[]=str.getBytes();
//        fileOutputStream.write(b);
//        fileInputStream.close();
//    }
//}

//
//import java.io.*;
//
//public class Main{
//    public static void main(String[] args) throws IOException{
//        FileInputStream fileInputStream= new FileInputStream("D:\\Java2.txt");
//        BufferedInputStream bufferedInputStream= new BufferedInputStream(fileInputStream);
//
//        while (bufferedInputStream.available()>0){
//                System.out.print((char)bufferedInputStream.read());
//        }
//        System.out.println("");
//
//        String str="Hello world";
//        FileOutputStream fileOutputStream= new FileOutputStream("D:\\Java2.txt");
//        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
//        byte b[]=str.getBytes();
//        bufferedOutputStream.write(b);
//        bufferedOutputStream.close();
//        fileOutputStream.close();
//    }
//}
//

//
//import java.io.File;
//import java.io.FileReader;
//import java.io.FileWriter;
//
//public class Main {
//    public static void main(String[] args){
//        FileReader fileReader=new FileReader("D:Java2.txt");
//        int c;
//        while((c=fileReader.read())!=1){
//            System.out.print((char)c);
//        }
//        System.out.println("");
//        FileWriter fileWriter=new FileWriter("D:Java2.txt");
//        String s="new World";
//        fileWriter.write(s);
//        fileWriter.close();
//    }
//}


//import java.io.*;
//
//public class Main {
//    public static void main(String[] args){
//        FileReader fileReader = new FileReader("D:\\Java2.txt");
//        BufferedReader bufferedReader = new BufferedReader(fileReader);
//        String s;
//        while((s=bufferedReader.readLine())!= null){
//            System.out.println(s);
//        }
//        FileWriter fileWriter= new FileWriter("D:\\Java2.txt");
//        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//        bufferedWriter.write("test string 1\n");
//        bufferedWriter.write("test string 2");
//        bufferedWriter.close();
//        fileWriter.close();
//    }
//}

import java.io.RandomAccessFile;

public class Main {
    public static void main(String[] args){
        RandomAccessFile randomAccessFile = new RandomAccessFile("D:Java.txt", "rw");
        randomAccessFile.writeUTF("Hello world><><");
        randomAccessFile.seek(0);
        System.out.println(randomAccessFile.readUTF());
    }
}