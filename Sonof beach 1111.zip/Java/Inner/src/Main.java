public class Main {
    public static void main(String[] args){
        PersonAccount personAccount=new PersonAccount( accountNumber: "abc123", bank: "Tbc", balance:  100);
        PersonAccount.PlasticCard card=personAccount.new PlasticCard(cardNumber:"525252", cardType: "debt", cardPincode:"00000");
        card.printInfo();
    }
}
