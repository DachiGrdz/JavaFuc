public class PersonAccount {
    private String accountNumber;
    private String bankName;
    private double balance;

    public class PlasticCard{
        private String cardNumber;
        private String cardType;
        private String cardPinCode;

        public void printInfo(){

            System.out.println("Account number = "+ PersonAccount.this.accountNumber);
            System.out.println("Bank name = "+PersonAccount.this.bankName);
            System.out.println("Balance = "+PersonAccount.this.balance);
            System.out.println("Card Number = "+this.cardNumber);
            System.out.println("Card Type = "+this.cardType);
            System.out.println("Card Pincode = "+this.cardPinCode);
        }

        public PlasticCard(String cardNumber,String cardType,String cardPinCode){}
        public String getCardNumber(){return cardNumber;}
        public void setCardNumber(String cardNumber){this.cardNumber = cardNumber;}
        public String getCardType(){return cardType;}
        public void setCardType(String cardType){this.cardType = cardType;}
        public String getCardPinCode(){return cardPinCode;}
        public void setCardPinCode(String cardPinCode){this.cardPinCode = cardPinCode;}
    }
}
