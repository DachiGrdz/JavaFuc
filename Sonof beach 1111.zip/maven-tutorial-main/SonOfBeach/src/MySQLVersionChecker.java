import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyS    QLVersionChecker {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/yourdatabase";
        String user = "username";
        String password = "password";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            DatabaseMetaData metaData = connection.getMetaData();
            String mysqlVersion = metaData.getDatabaseProductVersion();
            System.out.println("MySQL Version: " + mysqlVersion);
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}