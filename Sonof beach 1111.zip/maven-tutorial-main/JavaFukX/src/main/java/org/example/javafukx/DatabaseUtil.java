package org.example.javafukx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/yourdatabase"; // Replace 'store' with your database name
        String username = "product"; // Replace with your database username
        String password = "Yes"; // Replace with your database password
        return DriverManager.getConnection(url, username, password);
    }
}
