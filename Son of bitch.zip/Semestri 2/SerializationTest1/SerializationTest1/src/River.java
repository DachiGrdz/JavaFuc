import java.io.Serializable;

public class River  implements Serializable {

    private String riverName;
    private double riverLength;

    public String getRiverName() {
        return riverName;
    }

    public void setRiverName(String riverName) {
        this.riverName = riverName;
    }

    public double getRiverLength() {
        return riverLength;
    }

    public void setRiverLength(double riverLength) {
        this.riverLength = riverLength;
    }
}
