import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Scanner scanner = new Scanner(System.in);
        System.out.println("შემოიტანეთ მდინარის დასახელება და სიგრძე");

        String name = scanner.next();
        double length = scanner.nextDouble();

        River river = new River();
        river.setRiverName(name);
        river.setRiverLength(length);

        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("G:\\serializedRivers.txt"));
        objectOutputStream.writeObject(river);
        objectOutputStream.close();

        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("G:\\serializedRivers.txt"));
        River river2 = (River) objectInputStream.readObject();

        System.out.println(river2.getRiverName() + " " + river2.getRiverLength());
    }
}
