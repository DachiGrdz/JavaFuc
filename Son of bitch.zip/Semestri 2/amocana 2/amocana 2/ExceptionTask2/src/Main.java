import java.util.Random;

public class Main {
    public static void main(String[] args) {

        int a[]=new int[10];
        int b[]=new int[10];

        Random random =new Random();

        for(int i=0;i<a.length;i++){

            a[i]=random.nextInt(4);
            b[i]=random.nextInt(4);

        }

        try {
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < b.length; j++) {

                    System.out.println(a[i] / b[j]);
                }
            }
        }
        catch (ArithmeticException e){

            System.out.println("ნულზე გაყოფის შეცდომა");
        }

    }
}
