public class Main {


/*    public static void myExceptionTest() throws ArithmeticException, ArrayIndexOutOfBoundsException {

        int a = 15;
        int b = 10;

        int c = 0;


        c = a / b;

        int arr[] = new int[10];

        System.out.println(arr[20]);


    }*/

    public static void main(String[] args) {

  /*      try {

            myExceptionTest();
        }catch (ArithmeticException e){

            System.out.println("ნულზე გაყოფის შეცდომა");
        }
        catch (ArrayIndexOutOfBoundsException e){

            System.out.println("მასივის საზღვრებს გარეთ გასვლა");
        }finally {
            System.out.println("I'm finally block");
        }
*/
        try {
            Person person = new Person("nika", "lutidze", "111111111111");
        } catch (IdNumException ex) {

            System.out.println(ex.getMessage());
        }

    }
}
