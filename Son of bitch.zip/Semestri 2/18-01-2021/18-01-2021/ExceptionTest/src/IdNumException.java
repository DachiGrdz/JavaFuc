public class IdNumException extends Exception {

    public IdNumException(String message) {
        super(message);
    }
}
