public class Person {

    private String name;
    private String lastName;
    private String idNum;

    public Person(String name, String lastName, String idNum) throws  IdNumException{
        this.name = name;
        this.lastName = lastName;

        if (idNum.length() != 11) {

            throw new IdNumException("არასწორი პირადი ნომერი");

        }
        this.idNum = idNum;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
