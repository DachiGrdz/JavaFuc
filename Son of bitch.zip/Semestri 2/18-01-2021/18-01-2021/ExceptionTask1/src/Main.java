import java.util.Random;

public class Main {
    public static void main(String[] args) {


        Random random = new Random();

        int arr[] = new int[10];

        for (int i = 0; i < arr.length; i++) {

            arr[i] = random.nextInt(10);
        }

        int jami = 0;

        try {
            for (int i = -1; i < arr.length; i++) {

                jami += arr[i];
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ინდექსი გაცდა მასივის საზღვრებს");
        }

        System.out.println(jami);

    }
}

