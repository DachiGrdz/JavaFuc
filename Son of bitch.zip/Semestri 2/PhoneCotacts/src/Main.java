import java.util.Scanner;

public class Main {


    private static PhoneCotact[] phoneContactsArr = new PhoneCotact[30];
    private static String name;
    private static String lastName;
    private static String phoneNumber;
    private static String email;
    private static Scanner scanner = new Scanner(System.in);

    private static int userChoice() {

        System.out.println("1-დამატება");
        System.out.println("2-რედაქტირება");
        System.out.println("3-წაშლა");
        System.out.println("4-კონტაქტების ნახვა");
        System.out.println("0 - პროგრამიდან გამოსვლა");

        int choice = scanner.nextInt();
        return choice;
    }

    private static void addContact() {

        System.out.println("შემოიტანეთ სახელი");
        name = scanner.next();
        System.out.println("შემოიტანეთ გვარი");
        lastName = scanner.next();
        System.out.println("შემოიტანეთ ტელეფონის ნომერი");
        phoneNumber = scanner.next();
        System.out.println("შემოიტანეთ იმეილი");
        email = scanner.next();

        PhoneCotact phoneCotact = new PhoneCotact();
        phoneCotact.setName(name);
        phoneCotact.setLastName(lastName);
        phoneCotact.setEmail(email);
        phoneCotact.setPhoneNumber(phoneNumber);

    }

    public static void main(String[] args) {

    }
}
