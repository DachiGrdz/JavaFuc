public class User {
    private String name;
    private String lastName;
    private String indNum;
    private String username;

    public User(String name, String lastName, String indNum, String username) {
        this.name = name;
        this.lastName = lastName;
        this.indNum = indNum;
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIndNum() {
        return indNum;
    }

    public void setIndNum(String indNum) {
        this.indNum = indNum;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
