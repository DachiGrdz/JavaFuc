import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {


        ArrayList<User> users =new ArrayList<>();
        users.add(new User("name1","lastname1","00000000001","user1"));
        users.add(new User("name2","lastname2","00000000002","user2"));


        String findUserByUsername="user1";

        User u1 = users.stream()
                .filter(e -> findUserByUsername.equals(e.getUsername()))
                .findAny()
                .orElse(null);

        if(u1!=null){
            System.out.println("aseti user arsebobs");
        }

        String findUserByIdNum="00000000002";

        User u2 = users.stream()
                .filter(e -> findUserByIdNum.equals(e.getIndNum()))
                .findAny()
                .orElse(null);


        if(u2!=null){
            System.out.println("aseti user arsebobs");
        }

    }
}
