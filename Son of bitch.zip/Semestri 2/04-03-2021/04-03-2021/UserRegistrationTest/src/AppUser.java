import java.io.Serializable;

public class AppUser implements Serializable {

    private String name;
    private String lastName;
    private String idNum;
    private String userName;
    private String passWord;

    public AppUser() {
    }

    public AppUser(String name, String lastName, String idNum, String userName, String passWord) {
        this.name = name;
        this.lastName = lastName;
        this.idNum = idNum;
        this.userName = userName;
        this.passWord = passWord;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    @Override
    public boolean equals(Object o) {
        AppUser appUser = (AppUser) o;
        return appUser.userName.equals(this.userName);
    }


    @Override
    public String toString() {
        return "AppUser{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
                ", userName='" + userName + '\'' +
                ", passWord='" + passWord + '\'' +
                '}';
    }
}
