import java.io.*;
import java.util.ArrayList;

public class FileInputOutput {

    private final String appUserFile = "D:\\apusers.txt";

    public void saveAppUser(ArrayList<AppUser> appUserArrayList) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(appUserFile);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(appUserArrayList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public ArrayList<AppUser> getAppUsers() {
        ArrayList<AppUser> appUsers = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(appUserFile);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            appUsers = (ArrayList<AppUser>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("ფაილი ვერ მოიძებნა");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return appUsers;
    }
}
