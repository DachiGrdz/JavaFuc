import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<AppUser> appUserArrayList = new ArrayList<>();

    private static void createNewUser() {
        String name;
        String lastName;
        String idNum;
        String userName;
        String password;

        System.out.println("შემოიტანეთ სახელი");
        name = scanner.next();
        System.out.println("შემოიტანეთ გვარი");
        lastName = scanner.next();
        System.out.println("შემოიტანეთ პირადი ნომერი");
        idNum = scanner.next();
        System.out.println("შემოიტანეთ user");
        userName = scanner.next();
        System.out.println("შემოიტანეთ პაროლი");
        password = scanner.next();

        AppUser appUser = new AppUser(name, lastName, idNum, userName, password);

        if (appUserArrayList.contains(appUser)) {
            System.out.println("ასეთი მომხმარებელი უკვე არსებობს");

        } else {
            appUserArrayList.add(appUser);
            System.out.println("რეგისტრაცია წარმატებით დასრულდა");
        }

    }

    public static void main(String[] args) {

        FileInputOutput fileInputOutput = new FileInputOutput();


        appUserArrayList = fileInputOutput.getAppUsers();

        createNewUser();

        fileInputOutput.saveAppUser(appUserArrayList);


    }
}
