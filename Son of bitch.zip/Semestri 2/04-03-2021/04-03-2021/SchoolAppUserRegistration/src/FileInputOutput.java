import java.io.*;
import java.util.ArrayList;

public class FileInputOutput {

    private final String adminFile = "G:\\admins.txt";

    public void addAdmins(ArrayList<Administrator> administratorArrayList) {

        try {
            FileOutputStream fileOutputStream = new FileOutputStream(adminFile);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(administratorArrayList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Administrator> getAdmins() {
        ArrayList<Administrator> administrators = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(adminFile);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            administrators = (ArrayList<Administrator>) objectInputStream.readObject();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return administrators;
    }
}
