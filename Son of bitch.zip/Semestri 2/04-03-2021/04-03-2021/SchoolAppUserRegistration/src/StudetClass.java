import java.io.Serializable;

public class StudetClass  implements Serializable {
    private int cclasId;

    private String className;

    public int getCclasId() {
        return cclasId;
    }

    public void setCclasId(int cclasId) {
        this.cclasId = cclasId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Override
    public String toString() {
        return "StudetClass{" +
                "cclasId=" + cclasId +
                ", className='" + className + '\'' +
                '}';
    }
}
