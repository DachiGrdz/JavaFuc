import java.io.Serializable;

public class Administrator implements Serializable {
    protected String name;
    protected String lastName;
    protected String idNum;
    protected String userName;
    protected String password;

    public Administrator() {
    }

    public Administrator(String name, String lastName, String idNum, String userName, String password) {
        this.name = name;
        this.lastName = lastName;
        this.idNum = idNum;
        this.userName = userName;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        Administrator administrator=(Administrator) o;

        return this.userName.equals(administrator.userName);
    }


    @Override
    public String toString() {
        return "Administrator{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
