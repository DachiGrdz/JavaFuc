import java.io.Serializable;
import java.util.ArrayList;

public class Teacher extends Administrator implements Serializable {

    private Subject subject;
    private ArrayList<StudetClass> studetClasses = new ArrayList<>();

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public ArrayList<StudetClass> getStudetClasses() {
        return studetClasses;
    }

    public void setStudetClasses(ArrayList<StudetClass> studetClasses) {
        this.studetClasses = studetClasses;
    }

    public Teacher() {

    }

    public Teacher(Subject subject) {
        this.subject = subject;
    }

    public Teacher(String name, String lastName, String idNum, String userName, String password, Subject subject) {
        super(name, lastName, idNum, userName, password);
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "subject=" + subject +
                ", studetClasses=" + studetClasses +
                ", name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
