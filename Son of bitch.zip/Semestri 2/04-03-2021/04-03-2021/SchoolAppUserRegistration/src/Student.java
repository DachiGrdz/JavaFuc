import java.io.Serializable;
import java.util.ArrayList;

public class Student extends Administrator implements Serializable {

    private ArrayList<Subject> subjectArrayList = new ArrayList<>();
    private StudetClass studetClass;


    public Student() {


    }

    public Student(String name, String lastName, String idNum, String userName, String password, ArrayList<Subject> subjectArrayList) {
        super(name, lastName, idNum, userName, password);
        this.subjectArrayList = subjectArrayList;
    }

    public ArrayList<Subject> getSubjectArrayList() {
        return subjectArrayList;
    }

    public void setSubjectArrayList(ArrayList<Subject> subjectArrayList) {
        this.subjectArrayList = subjectArrayList;
    }

    public StudetClass getStudetClass() {
        return studetClass;
    }

    public void setStudetClass(StudetClass studetClass) {
        this.studetClass = studetClass;
    }

    @Override
    public String toString() {
        return "Student{" +
                "subjectArrayList=" + subjectArrayList +
                ", studetClass=" + studetClass +
                ", name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
