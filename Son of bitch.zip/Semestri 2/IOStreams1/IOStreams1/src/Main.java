import java.io.*;

public class Main {

    public static void main(String[] args) throws IOException {

    /*  //ფაილიდან წაკითხვა

        FileInputStream fileInputStream = new FileInputStream("F:\\test.txt");

        int content = -1;

        while ((content = fileInputStream.read()) != -1) {

            System.out.print((char) content);
        }

*/
        //ფაილში ჩაწერა
         String Write = "We are learning java";
        int x = 65;
        String textToWrite = Integer.toString(x);

        FileOutputStream fileOutputStream = new FileOutputStream("F:\\result.txt");

        byte arr[] = Write.getBytes();

        fileOutputStream.write(arr);
        fileOutputStream.close();

     /*   FileInputStream fileInputStream = new FileInputStream("F:\\test.txt");
        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
        while (bufferedInputStream.available() > 0) {

            System.out.print((char) bufferedInputStream.read());
        }
*/

 /*       FileOutputStream fileOutputStream = new (fileOutputStream);
        String s = "bufferedutputstream";
FileOutputStream("F:result.txt");
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream
        byte[] arr = s.getBytes();
        bufferedOutputStream.write(arr);
        bufferedOutputStream.close();
        fileOutputStream.close();*/

    }
}
