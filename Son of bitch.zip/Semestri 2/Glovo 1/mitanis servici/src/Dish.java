import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class Dish implements Serializable {
    @Serial
    private static final long serialVersionUID = 2L;
    private String restaurant;
    private String name;
    private float price;

    public Dish() {}

    public Dish(String restaurant, String name, float price) {
        this.restaurant = restaurant;
        this.name = name;
        this.price = price;
    }

    public String getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(String restaurant) {
        this.restaurant = restaurant;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return ""+name+" ---> "+price+"ლ";
    }

    @Override
    public boolean equals(Object o) {
        Dish dish = (Dish) o;
        return dish.restaurant.equals(this.restaurant) &&  dish.name.equals(this.name);

    }

}
