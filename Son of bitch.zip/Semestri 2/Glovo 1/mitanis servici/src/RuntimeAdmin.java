import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;

public class RuntimeAdmin {
    private final FileInputOutput fileInputOutput = new FileInputOutput();

    public void chooseFunction(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("საჭმლის გამოძახებისთვის 1" + "\n"+
                "კერძის სრულ მენიუში დამატებისთვის 2" + "\n"
        +"ახალი ადმინისტრატორის შექმნისთვის 3" + "\n" +
                "კერძის წაშლისთვის 4"+ "\n"+
                "კერძის ფასის შეცვლისთვის 5" + "\n" +
                "მომხმარებლის წაშლისთვის 6");
        int chooseFunq = scanner.nextInt();
        if (chooseFunq == 1){
            FoodOrder foodOrder = new FoodOrder();
            foodOrder.OrderFood();
        }
        else if (chooseFunq == 2){
            System.out.println("შემოიტანეთ რესტორანი: ");
            String restaurant = scanner.next();

            System.out.println("შემოიტანეთ კერძის სახელი: ");
            String name = scanner.next();

            System.out.println("შემოიტანეთ ფასი: ");
            float price = scanner.nextFloat();
            Dish dish = new Dish(restaurant,name,price);
            ArrayList<Dish> menu = fileInputOutput.getMenuAll();
            menu.add(dish);
            fileInputOutput.saveMenu(menu);
        }
        else if (chooseFunq == 3){
            RuntimeMain.createNewUser();
        }
        else if (chooseFunq == 4){
            ArrayList<Dish>menu = fileInputOutput.getMenuAll();
            ArrayList<String>listOfRestaurants = new ArrayList<>();
            for (Dish value : menu) {
                if (!listOfRestaurants.contains(value.getRestaurant())) {
                    listOfRestaurants.add(value.getRestaurant());
                }
            }
            System.out.println(listOfRestaurants.toString());
            System.out.println("შემოიტანეთ რესტორნის სახელი: ");
            String restaurant = scanner.next();
            menu.stream()
                    .filter(e -> restaurant.equals(e.getRestaurant()))
                    .forEach(e -> System.out.println(e.toString()));
            System.out.println("შემოიტანეთ კერძის სახელი: ");
            String name = scanner.next();
            Dish dish = new Dish(restaurant,name , 0);
            if(menu.contains(dish)){
                for (int i=0;i<menu.size();i++){
                    if(menu.get(i).equals(dish)){
                        menu.remove(i);
                    }
                }
            }
            fileInputOutput.saveMenu(menu);
            System.out.println("ოპერაცია შესრულდა");
        }
        else if (chooseFunq == 5){
            ArrayList<Dish>menu = fileInputOutput.getMenuAll();
            ArrayList<String>listOfRestaurants = new ArrayList<>();
            for (Dish value : menu) {
                if (!listOfRestaurants.contains(value.getRestaurant())) {
                    listOfRestaurants.add(value.getRestaurant());
                }
            }
            System.out.println(listOfRestaurants.toString());
            System.out.println("შემოიტანეთ რესტორნის სახელი: ");
            String restaurant = scanner.next();
            menu.stream()
                    .filter(e -> restaurant.equals(e.getRestaurant()))
                    .forEach(e -> System.out.println(e.toString()));
            System.out.println("შემოიტანეთ კერძის სახელი: ");
            String name = scanner.next();
            System.out.println("შემოიტანეთ სასურველი ფასი: ");
            float price = scanner.nextFloat();
            Dish dish = new Dish(restaurant,name , 0);
            if(menu.contains(dish)){
                for (Dish value : menu) {
                    if (value.equals(dish)) {
                        value.setPrice(price);
                    }
                }
            }
            fileInputOutput.saveMenu(menu);
        }
        else if (chooseFunq == 6){
            ArrayList<User>users = fileInputOutput.getUsers();
            System.out.println("შემოიტანეთ username: ");
            String username = scanner.next();
            User user = users.stream()
                    .filter(e -> username.equals(e.getUserName()))
                    .findAny()
                    .orElse(null);
            users.remove(user);
            fileInputOutput.saveAppUser(users);

        }

    }
}
