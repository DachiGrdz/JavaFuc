import java.util.ArrayList;
import java.util.Scanner;

public class RuntimeMain {
    public RuntimeMain() {
    }

    private static final Scanner scanner = new Scanner(System.in);

    private int runtimeId;

    public void setRuntimeId(int runtimeId) {
        this.runtimeId = runtimeId;
    }

    public int getRuntimeId() {
        return runtimeId;
    }

    public static User createNewUser() {
        String name;
        String lastName;
        String idNum;
        String userName;
        String password;

        System.out.println("შემოიტანეთ სახელი");
        name = scanner.next();
        System.out.println("შემოიტანეთ გვარი");
        lastName = scanner.next();
        System.out.println("შემოიტანეთ პირადი ნომერი");
        idNum = scanner.next();
        System.out.println("შემოიტანეთ user");
        userName = scanner.next();
        System.out.println("შემოიტანეთ პაროლი");
        password = scanner.next();

        return new User(name, lastName, idNum, userName, password , false);

    }
    public static User createNewAdmin() {
        User admin = createNewUser();
        admin.setStatus(true);
        return admin;
    }
    public static boolean logInOrCreate(){
        FileInputOutput fileInputOutput = new FileInputOutput();
        ArrayList<User> userArrayList = fileInputOutput.getUsers();
        boolean logInOrCreate;
        System.out.println("რეგისტრაციისთვის შემოიტანეთ false " + "\n"
                +"წინააღმდეგ შემთხვევაში true");

        logInOrCreate = scanner.nextBoolean();

        if(logInOrCreate){
            String userName;
            String password;
            boolean logInCycle;
            do {
                logInCycle = false;
                String yOrN;
                System.out.println("გთხოვთ შემოიტანეთ username: ");
                userName = scanner.next();
                System.out.println("გთხოვთ შემოიტანეთ password: ");
                password = scanner.next();
                User user = new User("a","a","a",userName,"a",false);
                User comparingUser = userArrayList.stream()
                        .filter(user::equals)
                        .findAny()
                        .orElse(null);
                if (comparingUser != null) {
                    if (comparingUser.getPassWord().equals(password)) {

                        if (comparingUser.isStatus()) {
                            System.out.println("წარმატებით შეხვედით ანგარიშზე ადმინისტრატორო " + userName);
                            return true;
                        }
                        System.out.println("წარმატებით შეხვედით თქვენ ანგარიშზე " + userName);
                        return false;
                    }
                    else{
                        String repeatPassInput;
                        System.out.println("არასწორი პაროლი");
                        do {
                            System.out.println("გინდათ სცადოთ თავიდან შემოტანა პაროლის Y/N: ");
                            repeatPassInput = scanner.next();
                            if (repeatPassInput.equals("y") || repeatPassInput.equals("Y")){
                                System.out.println("შემოიტანეთ password: ");
                                password = scanner.next();
                                if (comparingUser.getPassWord().equals(password)){
                                    if (comparingUser.isStatus()){
                                        System.out.println("წარმატებით შეხვედით ანგარიშზე ადმინისტრატორო " + userName);
                                        return true;
                                    }
                                    System.out.println("წარმატებით შეხვედით თქვენ ანგარიშზე" + userName);
                                    return false;

                                }
                                else{
                                    System.out.println("თქვენ მიერ შემოტანილი პაროლი კვლავ არასწორია."+
                                            "\n" + "გინდათ სცადოთ თავიდან შემოტანა პაროლის Y/N: ");
                                    repeatPassInput = scanner.next();
                                }
                            }
                        } while (repeatPassInput.equals("y"));

                    }
                }
                else {
                    System.out.println("ტქვენ მიერ შემოტანილი ანდგარიში არ არსებობს თავიდან ცდა გნებავთ? Y/N: ");
                    yOrN = scanner.next();
                    if (yOrN.equals("y")){
                        logInCycle = true;
                    }
                }
            }while(logInCycle);


        }

        else{
            User newUser = createNewUser();
            userArrayList.add(newUser);
            fileInputOutput.saveAppUser(userArrayList);
            return false;
        }
        return false;

    }
}
