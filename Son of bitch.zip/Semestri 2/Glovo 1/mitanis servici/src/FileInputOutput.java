import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class FileInputOutput {
    public final String UserFile = "D:\\users.txt";
    public final String RestFile = "D:\\dishes.txt";

    public void saveAppUser(ArrayList<User> userArrayList) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(UserFile);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(userArrayList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public ArrayList<User> getUsers() {
        ArrayList<User> users = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(UserFile);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            users = (ArrayList<User>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return users;

    }
    public ArrayList<Dish> getMenu(String restaurant){
        ArrayList<Dish> menu = getMenuAll();
        for (int i=0,d = menu.size(); i<d;i++){
            if (menu.get(i).getName().equals(restaurant)){}
            else {
                menu.remove(i);
                d--;
            }
        }
        return menu;

    }
    public ArrayList<Dish> getMenuAll(){
        ArrayList<Dish> menu = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(RestFile);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            menu = (ArrayList<Dish>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        }
        catch (FileNotFoundException e){
            System.out.println("file not found");
        }
        catch (IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
        return menu;

    }
    public void saveMenu(ArrayList<Dish> dishArrayList){
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(RestFile);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(dishArrayList);
            objectOutputStream.close();
            fileOutputStream.close();
        }
        catch (FileNotFoundException e){
            System.out.println("file not found");
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

}
