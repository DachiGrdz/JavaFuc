import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<User> userArrayList = new ArrayList<>();
    public static void main(String[] args) {
        RuntimeMain runtime = new RuntimeMain();
        RuntimeAdmin runtimeAdmin = new RuntimeAdmin();
        if (RuntimeMain.logInOrCreate()){
            runtime.setRuntimeId(1);
        }
        if (runtime.getRuntimeId() == 1){
            runtimeAdmin.chooseFunction();
        }




    }
}