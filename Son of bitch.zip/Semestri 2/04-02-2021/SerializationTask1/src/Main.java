import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Scanner scanner = new Scanner(System.in);
        String name;
        double population;
        double area;

        Country arr[] = new Country[5];

        for (int i = 0; i < arr.length; i++) {

            System.out.println("შემოიტანეთ  ქვეყნის დასახელება");
            name = scanner.next();
            System.out.println("შემოიტანეთ ფართობი");
            area = scanner.nextDouble();
            System.out.println("შემოიტანეთ მოსახლეობა");
            population = scanner.nextDouble();

            Country country = new Country();
            country.setName(name);
            country.setArea(area);
            country.setPopilation(population);

            arr[i] = country;
        }

        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("G:\\country.txt"));
        objectOutputStream.writeObject(arr);
        objectOutputStream.close();

        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("G:\\country.txt"));
        Country resultArr[] = (Country[]) objectInputStream.readObject();

        System.out.println("------");


        for (int i = 0; i < resultArr.length; i++) {

            System.out.println(resultArr[i]);
        }
    }
}
