import java.io.Serializable;

public class Country  implements Serializable {

    private String name;
    private double popilation;
    private double area;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPopilation() {
        return popilation;
    }

    public void setPopilation(double popilation) {
        this.popilation = popilation;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "Country{" +
                "name='" + name + '\'' +
                ", popilation=" + popilation +
                ", area=" + area +
                '}';
    }
}
