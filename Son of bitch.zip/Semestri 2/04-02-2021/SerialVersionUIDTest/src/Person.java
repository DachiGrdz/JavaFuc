import java.io.Serializable;

public class Person implements Serializable {

    public String name;
    public String lastName;
    public String idNum;
    //public String nickName;

    final static long serialVersionUID=100L;



    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
            /*    ", nickName='" + nickName + '\'' +*/
                '}';
    }
}
