import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

  /*      Person person =new Person();
        person.name="name1";
        person.lastName="lastname1";
        person.idNum="00000001";
        person.nickName="nichname1";

        ObjectOutputStream objectOutputStream =new ObjectOutputStream(new FileOutputStream("G:\\serialversionuid.txt"));

        objectOutputStream.writeObject(person);
        objectOutputStream.close();*/

        ObjectInputStream objectInputStream =new ObjectInputStream(new FileInputStream("G:\\serialversionuid.txt"));
        Person resultPerson=(Person)objectInputStream.readObject();
        System.out.println(resultPerson);

    }
}
