import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Scanner scanner =new Scanner(System.in);

        String name;
        String lastName;
        String idNum;
        String nichName;

        System.out.println("შემოიტანეთ სახელი");
        name=scanner.next();
        System.out.println("შემოიტანეთ გვარი");
        lastName=scanner.next();
        System.out.println("შემოიტანეთ პირადი ნომერი");
        idNum=scanner.next();
        System.out.println("შემოიტანეთ ზედმეტსახელი");
        nichName=scanner.next();

        Person person =new Person();
        person.setName(name);
        person.setLastName(lastName);
        person.setIdNum(idNum);
        person.setNickName(nichName);

        ObjectOutputStream objectOutputStream =new ObjectOutputStream(new FileOutputStream("G:\\person.txt"));
        objectOutputStream.writeObject(person);
        objectOutputStream.close();

        ObjectInputStream objectInputStream =new ObjectInputStream(new FileInputStream("G:\\person.txt"));
        Person resultPerson=(Person)objectInputStream.readObject();

        System.out.println("---------");

        System.out.println(resultPerson);



    }
}
