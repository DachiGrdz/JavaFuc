package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    Person person = new Person();
    @FXML
    TextField nameTextField;
    @FXML
    TextField lastNameTextField;
    @FXML
    TextField idNumTextField;
    @FXML
    PasswordField passField;
    @FXML
    Button saveButton;

    @FXML
    ComboBox sqesiCombo;

    public void clickOnSaveButton() {

        person.setIdNum(idNumTextField.getText());
        person.setName(nameTextField.getText());
        person.setLastName(lastNameTextField.getText());
        person.setPassword(passField.getText());
        String sqesi= sqesiCombo.getSelectionModel().getSelectedItem().toString();
        person.setSqesil(sqesi);
        FileIo fileIo = new FileIo();
        ArrayList<Person> personArrayList = new ArrayList<>();
        personArrayList.add(person);
        fileIo.saveInfo(personArrayList);

        idNumTextField.clear();
        nameTextField.clear();
        lastNameTextField.clear();
        passField.clear();

        System.out.println(person);

    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        sqesiCombo.getItems().addAll("mamrobiti");
        sqesiCombo.getItems().addAll("mdedrobiti");
    }
}
