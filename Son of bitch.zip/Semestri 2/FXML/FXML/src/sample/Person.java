package sample;

import java.io.Serializable;

public class Person implements Serializable {

    private String name;
    private String lastName;
    private String idNum;
    private String password;
    private String  sqesil;

    public Person() {
    }


    public Person(String name, String lastName, String idNum, String password, String sqesil) {
        this.name = name;
        this.lastName = lastName;
        this.idNum = idNum;
        this.password = password;
        this.sqesil = sqesil;
    }

    public String getSqesil() {
        return sqesil;
    }

    public void setSqesil(String sqesil) {
        this.sqesil = sqesil;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNum='" + idNum + '\'' +
                ", password='" + password + '\'' +
                ", sqesil='" + sqesil + '\'' +
                '}';
    }
}
