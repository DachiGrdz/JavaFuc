import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
//        ფაილში ჩაწერა
//        Scanner scanner = new Scanner(System.in);
//        String name;
//        String lastName;
//
//        System.out.println("shemoitanet saxeli");
//        name = scanner.next();
//        System.out.println("shemoitanet gvari");
//        lastName = scanner.next();
//
//        FileWriter fileWriter = new FileWriter("D:\\Java.txt");
//        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//        bufferedWriter.write(name + " " + lastName);
//        bufferedWriter.close();
//        fileWriter.close();
//

        //ფაილიდან წაკითხვა
//        FileReader fileReader = new FileReader("G:\\input.txt");
//        BufferedReader bufferedReader = new BufferedReader(fileReader);
//
//
//        String s = "";
//
//        while ((s = bufferedReader.readLine()) != null) {
//
//            System.out.println(s);
//
//        }

//        bufferedReader.close();
//        fileReader.close();
*/

/*
        String str = "todo";
        RandomAccessFile randomAccessFile = new RandomAccessFile("G:\\readWrite.txt", "rw");
        randomAccessFile.writeUTF(str);
        randomAccessFile.seek(0);
        System.out.println(randomAccessFile.readUTF());*/

    }
}
