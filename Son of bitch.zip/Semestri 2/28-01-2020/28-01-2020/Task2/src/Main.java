import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {


        FileReader fileReader = new FileReader("D:\\numbers.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        int[] arr = new int[10];
        int i = 0;
        String s = "";
        int jami = 0;
        while ((s = bufferedReader.readLine()) != null) {

            arr[i] = Integer.parseInt(s);
            jami += arr[i];
            i++;
        }

        bufferedReader.close();
        fileReader.close();

        FileWriter fileWriter = new FileWriter("D:\\result.txt");
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        for (int j = 0; j < arr.length; j++) {

            bufferedWriter.write(arr[j] + " ");
        }

        bufferedWriter.write("jami="+jami);

        bufferedWriter.close();
        fileWriter.close();


    }
}
