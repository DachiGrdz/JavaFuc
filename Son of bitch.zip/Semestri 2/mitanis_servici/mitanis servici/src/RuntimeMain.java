import java.util.ArrayList;
import java.util.Scanner;

public class RuntimeMain {
    public RuntimeMain() {
    }

    private static final Scanner scanner = new Scanner(System.in);

    private int runtimeId;

    public void setRuntimeId(int runtimeId) {
        this.runtimeId = runtimeId;
    }

    public int getRuntimeId() {
        return runtimeId;
    }

    public static User createNewUser() {
        String name;
        String lastName;
        String idNum;
        String userName;
        String password;

        System.out.println("შემოიტანეთ სახელი");
        name = scanner.next();
        System.out.println("შემოიტანეთ გვარი");
        lastName = scanner.next();
        System.out.println("შემოიტანეთ პირადი ნომერი");
        idNum = scanner.next();
        System.out.println("შემოიტანეთ user");
        userName = scanner.next();
        System.out.println("შემოიტანეთ პაროლი");
        password = scanner.next();

        return new User(name, lastName, idNum, userName, password , false);

    }
    public static int logInOrCreate(){
        FileInputOutput fileInputOutput = new FileInputOutput();
        ArrayList<User> userArrayList = fileInputOutput.getUsers();
        boolean logInOrCreate;
        System.out.println("რეგისტრაციისთვის შემოიტანეთ false " + "\n"
                +"წინააღმდეგ შემთხვევაში true");

        logInOrCreate = scanner.nextBoolean();

        if(logInOrCreate){
            String userName;
            String password;
            boolean logInCycle;
            do {
                System.out.println("გთხოვთ შემოიტანეთ username: ");
                userName = scanner.next();
                System.out.println("გთხოვთ შემოიტანეთ password: ");
                password = scanner.next();
                User user = new User("a","a","a",userName,password,false);
                User admin = new User("a","a","a",userName,password,true);

                if(userArrayList.contains(user)){
                    System.out.println("წარმატებით დარეგისტრირდით " + userName);
                    return 0;


                }
                else if (userArrayList.contains(admin)){
                    System.out.println("კეთილი იყოს თქვენი დაბრუნება "+ userName);
                    return 1;
                }

                else {
                    System.out.println("თქვენ მიერ შემოტანილი ემაილი ან პაროლი არასწორია" + "\n");
                    System.out.println("თავიდან ცდა თუ გნებავთ გთხოვთ დაწერეთ true: ");
                    logInCycle = scanner.nextBoolean();

                }
            }while(logInCycle);


        }

        else{
            User newUser = createNewUser();
            userArrayList.add(newUser);
            fileInputOutput.saveAppUser(userArrayList);
            return 2;
        }
        return 69;

    }
}
