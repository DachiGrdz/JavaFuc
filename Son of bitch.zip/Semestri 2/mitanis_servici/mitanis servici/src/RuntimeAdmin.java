import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class RuntimeAdmin {
    private FileInputOutput fileInputOutput = new FileInputOutput();

    public void chooseFunction(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("საჭმლის გამოძახებისთვის 1" + "\n"+
                "კერძის სრულ მენიუში დამატებისთვის 2");
        int chooseFunq = scanner.nextInt();
        if (chooseFunq == 1){
            FoodOrder fO = new FoodOrder();
            String restaurant = scanner.next();
            fO.OrderFood(restaurant);
        }
        else if (chooseFunq == 2){
            String restaurant = scanner.next();
            String name = scanner.next();
            float price = scanner.nextFloat();
            Dish dish = new Dish(restaurant,name,price);
            ArrayList<Dish> menu = fileInputOutput.getMenuAll();
            fileInputOutput.saveMenu(menu);
        }
        else{
            System.out.println("more functions comming soon");
        }
    }
}
