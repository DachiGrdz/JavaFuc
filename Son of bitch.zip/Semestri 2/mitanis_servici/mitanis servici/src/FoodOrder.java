import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FoodOrder {
    private float price = 0;
    private int numberOfDishes;
    Scanner scanner = new Scanner(System.in);

    public FoodOrder() { }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public void OrderFood(String restaurant){
        FileInputOutput fileInputOutput = new FileInputOutput();
        ArrayList<Dish> menu = new ArrayList<>();
        menu = fileInputOutput.getMenu(restaurant);
        menu.toString();
        System.out.println("-----------------------");
        System.out.println("შეიტანეთ მენიუს კერძების სახელები ხოლო როდესაც მორჩებით დააჭირეთ q-ს");
        String item;
        do{
                item = scanner.next();
                for(int i=0; i<menu.size();i++){
                    if(item == menu.get(i).getName()){
                        setPrice(getPrice()+menu.get(i).getPrice());
                        System.out.println("თქვენ შეიძინეთ "+menu.get(i).getName());
                        break;
                    }
                }
        }while(item != "q");
        System.out.println("თქვენ მოგიწევთ კურიერისთვის "+price+"ის მიცემა");

    }

}
