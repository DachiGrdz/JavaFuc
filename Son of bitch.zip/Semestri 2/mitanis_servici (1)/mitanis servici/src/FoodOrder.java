import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FoodOrder {
    private float price = 0;
    private int numberOfDishes = 0;
    Scanner scanner = new Scanner(System.in);

    public FoodOrder() { }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public void OrderFood(){
        FileInputOutput fileInputOutput = new FileInputOutput();
        ArrayList<Dish>menu = fileInputOutput.getMenuAll();
        ArrayList<String>listOfRestaurants = new ArrayList<>();
        for (Dish value : menu) {
            if (!listOfRestaurants.contains(value.getRestaurant())) {
                listOfRestaurants.add(value.getRestaurant());
            }
        }
        System.out.println(listOfRestaurants.toString());
        System.out.println("შემოიტანეთ იმ რესტორანის სახელი რომლიდან შეძენაც გსურთ: ");
        String restaurant = scanner.next();
        menu.stream()
                .filter(e -> restaurant.equals(e.getRestaurant()))
                .forEach(e -> System.out.println(e.toString()));
        System.out.println("-----------------------");
        System.out.println("შეიტანეთ მენიუს კერძების სახელები ხოლო როდესაც მორჩებით დააჭირეთ q-ს");
        String item;
        do{
                item = scanner.next();
            for (Dish dish : menu) {
                if (item.equals(dish.getName())) {
                    setPrice(getPrice() + dish.getPrice());
                    System.out.println("თქვენ შეიძინეთ " + dish.getName());
                    break;
                }
            }
        }while(!item.equals("q"));
        System.out.println("თქვენ მოგიწევთ კურიერისთვის "+price+" ლარის ის მიცემა");

    }

}
