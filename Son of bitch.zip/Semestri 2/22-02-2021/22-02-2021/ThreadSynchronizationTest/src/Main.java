public class Main {
    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount();
        Person person = new Person(bankAccount);
        Person person2 = new Person(bankAccount);

        person.start();
        person2.start();

    }
}
