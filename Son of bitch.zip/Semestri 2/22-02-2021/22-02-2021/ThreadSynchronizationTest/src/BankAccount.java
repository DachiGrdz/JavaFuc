public class BankAccount {
    private int balance = 10;

    public int getBalance() {
        return balance;
    }

    public synchronized void getCash(int cash) {
        if (cash <= balance) {
            System.out.println("თახა გამოტანილია ანგარიშიდან " + this.balance);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            balance = balance - cash;


        }

    }
}
