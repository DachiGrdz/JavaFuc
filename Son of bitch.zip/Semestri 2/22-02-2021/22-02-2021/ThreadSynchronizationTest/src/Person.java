public class Person extends Thread {

    BankAccount bankAccount;

    public Person(BankAccount bankAccount) {

        this.bankAccount = bankAccount;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            this.bankAccount.getCash(5);
        }

        if(this.bankAccount.getBalance()<=0){
            System.out.println("ანგარიშზე არ არის საკმარისი თანხა");
        }
    }
}
