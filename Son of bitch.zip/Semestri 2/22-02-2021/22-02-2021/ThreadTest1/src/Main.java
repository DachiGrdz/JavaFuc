public class Main {
    public static void main(String[] args) {


        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.setName("thread 1");

        MyThread myThread2 = new MyThread();
        Thread thread2 = new Thread(myThread2);
        thread2.setName("thread 2");

        MyThread myThread3 = new MyThread();
        Thread thread3 = new Thread(myThread3);
        thread3.setName("thread 3");


        thread.start();
        thread2.start();
        thread3.start();



        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

         System.out.println("Main Thread");


//        Thread thread = Thread.currentThread();
//
//        System.out.println("Thread name = " + thread.getName());
//        System.out.println("Thread priority = "+thread.getPriority());
//        thread.setName("T2");
//        thread.setPriority(7);
//        System.out.println("Thread name after change = "+thread.getName());
//        System.out.println("Thread priority after change = "+thread.getPriority());
//
//
//    MyThread2 myThread2 =new MyThread2();
//    myThread2.start();

    }
}
