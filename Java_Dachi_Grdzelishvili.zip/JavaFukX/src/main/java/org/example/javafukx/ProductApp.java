package org.example.javafukx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.javafukx.Product;

import java.sql.*;
import java.util.*;

public class ProductApp extends Application {

    private TableView<Product> table;
    private PieChart pieChart;

    @Override
    public void start(Stage primaryStage) {
        // Create UI components
        TextField nameField = new TextField();
        TextField quantityField = new TextField();
        TextField priceField = new TextField();
        Button addButton = new Button("Add Product");
        table = new TableView<>();
        pieChart = new PieChart();

        // Add columns to the table
        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        TableColumn<Product, Integer> quantityColumn = new TableColumn<>("Quantity");
        TableColumn<Product, Double> priceColumn = new TableColumn<>("Price");

        table.getColumns().addAll(nameColumn, quantityColumn, priceColumn);

        // Layout
        VBox root = new VBox(
                new HBox(new Label("Name:"), nameField),
                new HBox(new Label("Quantity:"), quantityField),
                new HBox(new Label("Price:"), priceField),
                addButton,
                table,
                pieChart
        );

        // Scene
        Scene scene = new Scene(root, 600, 400);

        // Show the stage
        primaryStage.setScene(scene);
        primaryStage.setTitle("Product Management App");
        primaryStage.show();

        // Button click event
        addButton.setOnAction(event -> {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());
            addProductToDatabase(name, quantity, price);
            updateTableAndPieChart();
        });

        // Initial load of table and pie chart data
        updateTableAndPieChart();
    }

    private void addProductToDatabase(String name, int quantity, double price) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO products (name, quantity, price) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setInt(2, quantity);
            statement.setDouble(3, price);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateTableAndPieChart() {
        List<Product> products = getProductsFromDatabase();
        table.getItems().setAll(products);
        updatePieChart(products);
    }

    private List<Product> getProductsFromDatabase() {
        List<Product> products = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT * FROM products";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                products.add(new Product(id, name, quantity, price));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    private void updatePieChart(List<Product> products) {
        Map<String, Integer> productQuantities = new HashMap<>();
        for (Product product : products) {
            productQuantities.put(product.getName(), productQuantities.getOrDefault(product.getName(), 0) + product.getQuantity());
        }

        pieChart.getData().clear();
        for (Map.Entry<String, Integer> entry : productQuantities.entrySet()) {
            pieChart.getData().add(new PieChart.Data(entry.getKey(), entry.getValue()));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
