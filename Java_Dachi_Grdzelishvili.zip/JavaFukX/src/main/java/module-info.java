module org.example.javafukx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens org.example.javafukx to javafx.fxml;
    exports org.example.javafukx;
}